"""Two du'as of one kind, side by side, as large as the screen will draw them.

The board used to show every du'a of a kind, up to five, which meant the Arabic had to be small
enough for the worst case. That is the wrong way round: this screen is read from a few feet away
while somebody is stood on the mat, so the words should be as big as the glass allows and the
number on screen should give way, not the size.

So: exactly two, one each side of a thick rule, at more than half again the old size, with
nothing else on the screen -- no Back button along the bottom, because that strip was costing
height that the Arabic wanted and there are two other ways back (the strip above, and the Du'as
tile on the 7in).

Which two is picked fresh every time the kind is opened. Every kind holds at least three, so
the pair changes, and over a few visits the whole kind is seen. Picking at the moment the kind
is opened rather than once at start-up is deliberate: it means going back in gives you different
du'as rather than the same ones until the mat is restarted.
"""
from __future__ import annotations

from .qt import QtCore, QtGui, QtWidgets, Qt, Signal
from .render import ArrowButton, Fonts, TextBox
from .theme import palette

ON_SCREEN = 2          # du'as shown at once: one each side of the rule
# The Arabic is drawn as large as its half of the screen will take. A single size cannot serve
# both a two-line du'a and 2:286 -- set big enough for the short one the long one runs off the
# bottom, and set small enough for the long one the short one wastes the glass. So the box picks,
# between these, and every du'a fits by construction rather than by luck.
ARABIC_FLOOR = 30
ARABIC_CAP = 110
RULE = 6               # the line between the columns, in unscaled pixels: thick, as asked

# The translation of a saying, which is now the only thing on its card. Lower than the Arabic's
# cap because Latin letters at 110px would give about eight words to a card, and higher than its
# floor because with the Arabic gone there is a whole card's worth of room for it.
SAYING_FLOOR = 26
SAYING_CAP = 64


class DuaCard(QtWidgets.QFrame):
    """One du'a: its name, the Arabic, the meaning underneath, and a play mark."""

    play = Signal(int)
    opened = Signal(int)

    def __init__(self, window, index: int, item, meaning: str, sayings: bool = False,
                 arabic_only: bool = False):
        super().__init__()
        self.win = window
        self.index = index
        self.item = item
        # Arabic only: the mat is set to show the Arabic and no meaning. For a du'a that means
        # dropping the line underneath. For a SAYING it means the opposite of the usual rule --
        # the translation is the whole card normally and there is no Arabic on it, so with the
        # translation gone there would be nothing on the card at all. The Arabic takes its
        # place, in the Arabic face and running right to left, which is the box that was
        # already built for it.
        self.arabic_only = arabic_only
        # Whether this card is a saying rather than a du'a. Three things follow from it: the
        # heading is the collection and number instead of a name, the play mark sits beside the
        # translation instead of over the Arabic, and there is no Arabic at all -- Harry asked
        # for the translation and the play button and nothing else.
        self.sayings = sayings
        self.setObjectName("duaCard")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(window.px(22), window.px(16), window.px(22), window.px(18))
        lay.setSpacing(window.px(10))
        self.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding,
                           QtWidgets.QSizePolicy.Policy.Expanding)

        top = QtWidgets.QHBoxLayout()
        top.setSpacing(window.px(10))
        self.button = QtWidgets.QToolButton()
        self.button.setObjectName("duaPlay")
        self.button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.button.setToolTip(window.t("quran.recite"))
        self.button.clicked.connect(lambda: self.play.emit(self.index))
        if not sayings:
            top.addWidget(self.button, 0, Qt.AlignmentFlag.AlignTop)

        # A du'a is headed by its name. A saying is headed by where it comes from -- the
        # collection and the number -- because that is the only heading for a hadith that is
        # not somebody's summary of it, and because it is what anybody wanting to check the
        # thing needs. The first go used the collection's own chapter name and put "Good
        # Manners and Form (Al-Adab)" over both cards on the screen at once.
        self.name = QtWidgets.QLabel(item.ref if sayings else item.title)
        self.name.setObjectName("duaCardName")
        self.name.setWordWrap(True)
        top.addWidget(self.name, 1)
        lay.addLayout(top)

        # by_word, so a word can go red while it is being said. It costs nothing here: the
        # card holds one du'a and is not paginated, so the tighter word-by-word layout cannot
        # change where anything breaks.
        self.arabic = TextBox(Fonts.arabic(window.settings.arabic_font),
                              ARABIC_FLOOR, ARABIC_CAP, rtl=True, by_word=True)
        self.arabic.scale = window.s
        self.arabic.set_lines([item.arabic])

        # No transliteration here. Ten of the forty-eight du'as had one and thirty-eight did
        # not, so it was a line that appeared on some cards and not others; and now that every
        # du'a can be heard read aloud, the way to learn how it sounds is to press play rather
        # than to read it in English letters. The room goes to the Arabic.

        self.meaning = QtWidgets.QLabel(meaning)
        self.meaning.setObjectName("duaCardMeaning")
        self.meaning.setWordWrap(True)
        if sayings:
            # The translation is the whole card now, so it is drawn in the same box the Arabic
            # had rather than in a label at a size fixed by the stylesheet: a narration runs
            # from a hundred letters to five hundred, and one size cannot serve both without
            # either overflowing the short card or wasting most of the long one.
            self.english = TextBox(Fonts.english_family, SAYING_FLOOR, SAYING_CAP,
                                   rtl=False, by_word=True)
            self.english.scale = window.s
            self.english.set_lines([meaning])
            shown = self.arabic if arabic_only else self.english
            under = QtWidgets.QHBoxLayout()
            under.setSpacing(window.px(10))
            under.addWidget(self.button, 0, Qt.AlignmentFlag.AlignTop)
            under.addWidget(shown, 1)
            lay.addLayout(under, 1)
            self.meaning.setVisible(False)
            self.arabic.setVisible(arabic_only)
            self.english.setVisible(not arabic_only)
        else:
            self.english = None
            lay.addWidget(self.arabic, 1)
            lay.addWidget(self.meaning)
            # Nothing to put under the Arabic, so nothing is put there -- rather than an empty
            # label holding open a gap the Arabic could have had.
            self.meaning.setVisible(not arabic_only)
        # The box the voice lights word by word as it reads: a du'a's Arabic, a saying's
        # translation. When Harry records the sayings the timings will be against the English,
        # which is the text on the screen -- so this is the box either way.
        self.words = self.english if (sayings and not arabic_only) else self.arabic
        self.draw_mark(False)

    # Twice what it was. It is the thing on this screen most likely to be aimed at -- there is
    # one per card and it is now the only way to hear a du'a read -- and at 46 it was a quarter
    # of the size of the card it sat on, which on a touchscreen is a thumb hunting for a stamp.
    MARK = 92

    def draw_mark(self, playing: bool) -> None:
        from .ui import play_icon
        side = self.win.px(self.MARK)
        icon = play_icon(side, palette().ink, stop=playing)
        self.button.setIcon(QtGui.QIcon(icon))
        self.button.setIconSize(icon.size())
        self.button.setFixedSize(side + self.win.px(10), side + self.win.px(10))

    def mouseReleaseEvent(self, ev):
        if self.rect().contains(ev.position().toPoint()):
            self.opened.emit(self.index)
        super().mouseReleaseEvent(ev)


class Rule(QtWidgets.QWidget):
    """The line between the columns. A painted widget rather than a styled QFrame, because a
    frame's line is one pixel whatever the stylesheet says on some styles, and this one has to
    be thick enough to read from across the room."""

    def __init__(self, window):
        super().__init__()
        self.win = window
        self.setObjectName("duaRule")
        self.setFixedWidth(window.px(RULE))
        self.setSizePolicy(QtWidgets.QSizePolicy.Policy.Fixed,
                           QtWidgets.QSizePolicy.Policy.Expanding)

    def paintEvent(self, _):
        p = QtGui.QPainter(self)
        p.fillRect(self.rect(), QtGui.QColor(palette().ink))


class DuaBoard(QtWidgets.QWidget):
    """Every du'a of one kind, in two columns."""

    chose = Signal(int)
    play = Signal(int)

    def __init__(self, window, passages, sayings: bool = False):
        super().__init__()
        self.win = window
        self.passages = passages
        self.sayings = sayings
        self.only = None
        # Which pair of the kind is up. See the note above pages().
        self.page = 0
        self.setObjectName("duaBoard")
        # Which card is being read aloud, if any, and the clock that follows the words.
        self.said_by: DuaCard | None = None
        self.follow = QtCore.QTimer(self)
        self.follow.setInterval(50)
        self.follow.timeout.connect(self.tick)

        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        head = QtWidgets.QHBoxLayout()
        head.setContentsMargins(window.px(20), window.px(10), window.px(20), 0)
        # The arrows sit at the right-hand end, under Main screen on the strip above, which
        # is where Harry pointed: "place them under the 'Main Screen' button, there is
        # space". The heading is centred on the screen and not on what is left of it, so
        # whatever the arrows take on the right is given back as a blank on the left.
        self.earlier = ArrowButton(False, window.pack.rtl)
        self.later = ArrowButton(True, window.pack.rtl)
        for button, forward in ((self.earlier, False), (self.later, True)):
            # Its own name, not the reading bar's: these are bigger, and they are red rather
            # than grey. A board is a screen you stand in front of and read two cards off, so
            # the way on is a thing you reach for, and on this mat the things you press are
            # red -- Menu, Main screen, Back.
            button.setObjectName("turnBoard")
            button.clicked.connect(lambda _=False, f=forward: self.turn(f))
        self.balance = QtWidgets.QWidget()
        head.addWidget(self.balance)
        head.addStretch(1)
        self.title = QtWidgets.QLabel("")
        self.title.setObjectName("namePlate")
        self.title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        head.addWidget(self.title)
        head.addStretch(1)
        pair = QtWidgets.QHBoxLayout()
        pair.setContentsMargins(0, 0, 0, 0)
        pair.setSpacing(window.px(14))
        pair.addWidget(self.earlier)
        pair.addWidget(self.later)
        head.addLayout(pair)
        outer.addLayout(head)

        self.scroll = QtWidgets.QScrollArea()
        self.scroll.setObjectName("listScroll")
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        # Two boxes side by side rather than one grid. In a grid every card in a row is as tall
        # as the tallest of them, so a short du'a beside 2:286 sat in a great well of empty
        # space. Boxes let each column pack to its own contents.
        inner = QtWidgets.QWidget()
        self.across = QtWidgets.QHBoxLayout(inner)
        self.across.setContentsMargins(window.px(20), window.px(12),
                                       window.px(20), window.px(20))
        self.across.setSpacing(window.px(20))
        self.left = QtWidgets.QVBoxLayout()
        self.left.setSpacing(window.px(14))
        self.right = QtWidgets.QVBoxLayout()
        self.right.setSpacing(window.px(14))
        self.across.addLayout(self.left, 1)
        self.across.addLayout(self.right, 1)
        self.scroll.setWidget(inner)
        outer.addWidget(self.scroll, 1)

        # No button strip along the bottom. It cost height the Arabic wanted, and there are two
        # other ways out of here: Main screen on the strip above, and the Du'as tile on the 7in,
        # which goes back to the kinds.
        self.cards: list[DuaCard] = []
        self.rule = None
        self.showing: list = []      # the pair picked for this visit
        self.filled = None

    def language(self) -> str:
        """Which meaning to show: the mat's language if the section has it, else English, and
        "" -- nothing -- when the mat is set to Arabic only.

        The mat asks this once, in Settings. It used to ask three times: a language, a
        "translation beside Arabic" underneath it, and a row of buttons on the reading bar,
        which all wrote to different settings. So the mat could sit there with Urdu menus and
        English du'as and every setting would have been obeyed. The reader makes the same
        choice from the same place, so the board and the page it opens never disagree.
        """
        from .ui import ARABIC_ONLY
        wanted = self.win.settings.lang or "en"
        if wanted == ARABIC_ONLY:
            return ""
        return wanted if wanted in self.passages.languages() else "en"

    def wanted(self) -> list[tuple[int, object]]:
        """The du'as of this kind, each with its place in the WHOLE section -- so opening one
        goes through the same door as it always did."""
        return [(i, item) for i, item in enumerate(self.passages.items)
                if self.only is None or self.only in item.cats]

    # -- walking a kind two at a time ---------------------------------------------------------
    #
    # Both boards are read this way rather than dealt. The sayings asked for it first: there
    # are a hundred and nine of them and a category holds five to eleven, so two drawn at
    # random is a glimpse of a category rather than a reading of it -- you could press a
    # heading six times and not see the one saying you were looking for. Harry: "this will
    # allow us to drop the randomiser and let the user scroll, this will also allow us to
    # obtain more hadiths and some do fall under multiple categories", and the second half is
    # why it matters more as the collection grows: a saying filed under two headings is
    # reachable under both, in its place, rather than being one more ticket in two raffles.
    #
    # The du'as followed a version later, and what went with them was a shuffled bag that
    # dealt two off the top each visit. It was careful work and it answered the wrong
    # question: "a different two each time" is not what you want stood on a mat, "the two I
    # was reading a moment ago" is.

    def pages(self) -> int:
        mine = self.wanted()
        return max(1, (len(mine) + ON_SCREEN - 1) // ON_SCREEN)

    def page_at(self, page: int) -> list:
        mine = self.wanted()
        page = max(0, min(page, self.pages() - 1))
        return mine[page * ON_SCREEN:(page + 1) * ON_SCREEN]

    def turn(self, forward: bool) -> None:
        """An arrow was pressed. Nothing happens at either end: the arrow there is dead."""
        want = self.page + (1 if forward else -1)
        if not 0 <= want < self.pages():
            return
        self.page = want
        self.showing = self.page_at(self.page)
        self.fill()
        self.to_the_top()
        self.dress_arrows()

    def dress_arrows(self) -> None:
        """Which way there is still something to go. Shown and dead rather than taken away,
        as everywhere else on the mat: a button that vanishes moves the other one."""
        self.earlier.setEnabled(self.page > 0)
        self.later.setEnabled(self.page < self.pages() - 1)
        # The blank that keeps the heading in the middle of the screen is whatever the pair
        # of arrows takes up. Asked of them rather than worked out, so it stays right at any
        # size, and set here because this runs whenever the pair might have changed.
        wide = self.earlier.sizeHint().width() + self.later.sizeHint().width() + self.win.px(14)
        self.balance.setFixedWidth(wide)

    def show_only(self, cat: str | None, heading: str = "") -> None:
        """Open a kind. This is where the pair is drawn -- not in fill(), which runs again
        whenever the screen is shown, and would otherwise swap the du'as under somebody who had
        stepped into one and come back."""
        self.only = cat or None
        if heading:
            self.title.setText(heading)
        self.page = 0
        self.showing = self.page_at(0)
        self.dress_arrows()
        self.filled = None
        self.fill()

    def clear(self) -> None:
        for box in (self.left, self.right):
            while box.count():
                old = box.takeAt(0)
                if old.widget() is not None:
                    old.widget().deleteLater()
        while self.across.count() > 2:
            old = self.across.takeAt(1)
            if old.widget() is not None:
                old.widget().deleteLater()
        self.cards, self.rule = [], None

    def fill(self) -> None:
        want = (tuple(i for i, _ in self.showing), self.language())
        if self.filled == want:
            return
        self.stop_saying()          # the cards are about to go; the voice must not outlive them
        self.filled = want
        self.clear()
        lang = self.language()
        for place, (index, item) in enumerate(self.showing):
            card = DuaCard(self.win, index, item, item.meaning(lang) if lang else "",
                           sayings=self.sayings, arabic_only=not lang)
            card.opened.connect(self.chose.emit)
            # Straight to the board's own player, with the card's place bound rather than the
            # du'a's number in the file: the board reads it here, so it is the board's business.
            card.play.connect(lambda _=0, k=place: self.say(k))
            (self.left if place == 0 else self.right).addWidget(card)
            self.cards.append(card)
        if len(self.showing) > 1:
            self.rule = Rule(self.win)
            self.across.insertWidget(1, self.rule)

    def to_the_top(self) -> None:
        self.scroll.verticalScrollBar().setValue(0)

    def showEvent(self, ev):
        self.fill()
        self.dress_arrows()
        super().showEvent(ev)

    def resizeEvent(self, ev):
        # The arrows are sized by the stylesheet, which is rebuilt for the new screen, so the
        # blank holding the heading in the middle has to be measured again.
        super().resizeEvent(ev)
        self.dress_arrows()

    def hideEvent(self, ev):
        # Leaving the screen stops the voice. A recording left playing to an empty room is the
        # thing hush_passages exists to prevent, and the board is another way to start one.
        self.stop_saying()
        super().hideEvent(ev)

    def follow_theme(self) -> None:
        for card in self.cards:
            card.draw_mark(card is self.said_by)
        if self.rule is not None:
            self.rule.update()

    def retitle(self) -> None:
        self.filled = None          # the meanings are in a language that may have changed
        self.fill()

    # -- reading one aloud, here on the board -------------------------------------------------

    def can_say(self, card) -> bool:
        item = card.item
        return bool(item.audio and item.times and self.win.recitation.available
                    and (self.win.assets / "audio" / item.audio).is_file())

    def say(self, place: int) -> None:
        """The play mark on a card was pressed.

        It reads the du'a on the card, here, with the word going red as it is said. It used to
        open the du'a's own page and read it there, which meant the two-column screen vanished
        the moment you pressed play -- you lost the du'a beside it and the thing you had been
        looking at was replaced by a different arrangement of the same words. Pressing it again
        stops; pressing the other card's mark moves the voice across.
        """
        card = self.cards[place] if 0 <= place < len(self.cards) else None
        if card is None:
            return
        if card is self.said_by:
            return self.stop_saying()
        self.stop_saying()
        if not self.can_say(card):
            # No recording for this one. Open it rather than doing nothing, which is what the
            # mark did for as long as there were no recordings at all.
            return self.chose.emit(card.index)
        from .audio import WHOLE, Span
        if not self.win.recitation.play(self.win.assets / "audio" / card.item.audio,
                                        Span(0.0, WHOLE)):
            return
        self.said_by = card
        card.draw_mark(True)
        self.follow.start()

    def stop_saying(self) -> None:
        if self.said_by is None:
            return
        self.follow.stop()
        self.win.recitation.stop()
        self.said_by.words.set_highlight(None)
        self.said_by.draw_mark(False)
        self.said_by = None

    @property
    def saying(self) -> bool:
        return self.said_by is not None

    def tick(self) -> None:
        """Light the word being said. One du'a on the card, so the line is always nought."""
        if self.said_by is None:
            return
        position = self.win.recitation.position()
        if position is None and not self.win.recitation.busy:
            return self.stop_saying()
        if position is None:
            return
        word = self.said_by.item.word_at(position)
        self.said_by.words.set_highlight(None if word is None else (0, word))
