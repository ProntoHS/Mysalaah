"""The Knowledge Corner on the big screen: the list of surahs, and reading one.

A surah is shown as an open book -- two pages side by side, turned by swiping. With a
translation chosen the meaning takes the left page and the Arabic the right, verse level with
verse, so the eye can go straight across. With no translation chosen there is nothing to put on
the left, so the Arabic takes both pages: the right one first, then the left, the way a book
with its spine on the right is read.

Nothing scrolls. A scrollbar on a mat is a poor thing to aim at, and there is no way to tell how
far through you are except by dragging. Pages are countable, and the ring button turns them as
happily as a finger does.

How many verses a page holds is not fixed. It is worked out from the room available and a floor
on how small the Arabic may be drawn -- a page of Al-Baqarah holds fewer verses than a page of
Al-Ikhlas because its verses are longer, which is exactly what a printed mushaf does too.
"""
from __future__ import annotations

from .audio import WHOLE, Span
from .qt import QtCore, QtGui, QtWidgets, Qt, Signal
from .quran import RTL, Quran, Surah, Verse
from .render import ArrowButton, Fonts, ParallelText, TextBox, TextSize
from .theme import palette

# The Arabic is never drawn smaller than this (at 1080p). Fitting more verses on a page by
# shrinking the script until it cannot be read would be the wrong trade every time.
FLOOR_PX = 30
MOST_VERSES = 40          # a page never holds more than this, however short the verses

# The three sizes the A buttons on the reading bar choose between. The first is what the mat
# has always done; each step after it is half as big again, which is what Harry asked for.
#
# They work by raising the FLOOR, not by setting a size. The page already grows its text to
# fill the room it has, so the thing that decides how big the Arabic comes out is how many
# verses were put on the page -- and that is settled by how small the words were allowed to
# get while they were being counted. Lift the floor and fewer verses fit; the page then fills
# with what is left, larger. It is the same mechanism a printed mushaf uses when it is set in
# a bigger face: not more ink on the page, but fewer verses on it.
TEXT_STEPS = (1.0, 1.5, 2.25)

# How tall the largest of the three A buttons is on the reading bar, at 1080p. 64, up from
# the 52 it was drawn at: Harry wanted it "slightly bigger", and the bar it lives in has the
# surah's name, a play button and the page arrows in it, so slightly is as far as it goes.
# The wu'du steps set their own, much larger -- see wudu.py.
READING_TEXT_SIZE_PX = 64

# Which way a swipe goes. Right-to-left means forward, as it does in every other touch screen
# the mat's owner uses. An Arabic book turns the other way, so this is the line to change if
# that matters more than the habit does.
FORWARD_IS_LEFT = True
SWIPE = 60                # pixels, at 1080p, before a drag counts as a page turn

# How long to wait for a verse to arrive before giving up on it. A verse is 143 KB, so this is
# generous; the point is that a connection which hangs leaves a message rather than a dead
# screen with the play button stuck on stop.
PATIENCE = 30.0

# The recite button. Glyphs, not words: see the note where the button is built.
PLAY = "\u25b6"
STOP = "\u25a0"


# The numbered square beside each surah, in one place so every one of the 114 is identical.
NUMBER_BOX = 64          # the square's side, before scaling
NUMBER_LINE = 4          # and how thick its outline is drawn

# The slider down the side of the lists. Four times the 14px a desktop gives it: this is a
# touchscreen, and 14px is a target for a mouse pointer, not for the side of a thumb. The lists
# resize to whatever the slider leaves, so the rows give up the width rather than the slider
# sitting on top of them.
#
# 42 at first, which was already three times a desktop's, and Harry has asked for it thicker
# twice since, each time after using it. He is the one dragging it on glass: 84px is about a
# centimetre and a half on the mat's screen, which is the width of the thumb doing the
# dragging rather than the width of the line somebody thought looked right.
LIST_BAR = 84


class SurahList(QtWidgets.QWidget):
    """All 114, in Arabic and in English, as a grid of touchable rows."""

    chose = Signal(int)
    COLUMNS = 3

    def __init__(self, window, quran: Quran):
        super().__init__()
        self.win = window
        self.quran = quran
        self.setObjectName("surahList")
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # The way out used to sit here. It is in the banner above this screen now, along with
        # the clock and the prayer times, so it is in the same place wherever you are.
        # No heading on it. It said "The 114 surahs", which is a caption telling you what you
        # are already looking at, and Harry asked for it gone -- but for the space it took to
        # stay, so the first row of surahs does not come up hard against the strip above.
        # The label is still here and still empty, which is what keeps that space: it is as
        # tall as a line of the heading's own type, at whatever size the screen is, and it
        # will follow the type if that ever changes. A fixed number of pixels here would not.
        bar = QtWidgets.QHBoxLayout()
        bar.setContentsMargins(self.win.px(20), self.win.px(10), self.win.px(20), 0)
        self.title = QtWidgets.QLabel("")
        self.title.setObjectName("readerTitle")
        bar.addWidget(self.title)
        bar.addStretch(1)
        outer.addLayout(bar)

        self.scroll = QtWidgets.QScrollArea()
        self.scroll.setObjectName("listScroll")
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        inner = QtWidgets.QWidget()
        self.grid = QtWidgets.QGridLayout(inner)
        self.grid.setContentsMargins(self.win.px(20), self.win.px(10),
                                     self.win.px(20), self.win.px(20))
        self.grid.setSpacing(self.win.px(10))
        self.scroll.setWidget(inner)
        outer.addWidget(self.scroll, 1)
        self.filled = False

    def showEvent(self, ev):
        # Built the first time it is looked at, not at start-up. 114 rows is the better part of
        # six hundred widgets, and most times the mat is switched on nobody opens this at all.
        self.fill()
        super().showEvent(ev)

    def fill(self) -> None:
        if self.filled:
            return
        self.filled = True
        while self.grid.count():
            item = self.grid.takeAt(0)
            if item.widget() is not None:
                item.widget().deleteLater()
        for i, surah in enumerate(self.quran.index):
            self.grid.addWidget(self.row(surah), i // self.COLUMNS, i % self.COLUMNS)

    def row(self, surah: Surah) -> QtWidgets.QWidget:
        b = QtWidgets.QPushButton()
        b.setObjectName("surahRow")
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.setMinimumHeight(self.win.px(96))
        b.clicked.connect(lambda _=False, n=surah.number: self.chose.emit(n))

        lay = QtWidgets.QHBoxLayout(b)
        lay.setContentsMargins(self.win.px(16), self.win.px(8), self.win.px(16), self.win.px(8))
        lay.setSpacing(self.win.px(12))

        # A square, fixed both ways, so 1 and 114 sit in boxes of exactly the same size and
        # the left-hand edge of every row lines up down the column.
        number = QtWidgets.QLabel(str(surah.number))
        number.setObjectName("surahNumber")
        number.setFixedSize(self.win.px(NUMBER_BOX), self.win.px(NUMBER_BOX))
        number.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(number)

        names = QtWidgets.QVBoxLayout()
        names.setSpacing(0)
        english = QtWidgets.QLabel(surah.name)
        english.setObjectName("surahName")
        meaning = QtWidgets.QLabel(f"{surah.meaning} · {surah.verses}")
        meaning.setObjectName("surahMeaning")
        names.addWidget(english)
        names.addWidget(meaning)
        lay.addLayout(names, 1)

        arabic = QtWidgets.QLabel(surah.arabic)
        arabic.setObjectName("surahArabic")
        arabic.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        lay.addWidget(arabic)
        return b

    def to_the_top(self) -> None:
        self.fill()
        self.scroll.verticalScrollBar().setValue(0)


class Spread(QtWidgets.QWidget):
    """Two pages of one surah, and the working out of where the pages fall."""

    turned = Signal()

    def __init__(self, window):
        super().__init__()
        self.win = window
        self.setObjectName("spread")
        self.verses: list[Verse] = []
        self.rtl_meaning = False
        self.pages: list[tuple[int, int]] = []     # (first verse index, one past the last)
        self.at = 0
        self._measured = None                      # the size the pages were worked out for
        self._down: QtCore.QPoint | None = None

        lay = QtWidgets.QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        # With a translation: one widget holding both columns, so each verse's two halves stay
        # level with each other. Without: two Arabic boxes, read right first.
        self.parallel = ParallelText(Fonts.arabic(self.win.settings.arabic_font),
                                     Fonts.english_family)
        # by_word so a single word can be lit while it is recited. It costs a word-by-word
        # layout pass instead of a line-by-line one; the page still breaks in the same places.
        self.left = TextBox(Fonts.arabic(self.win.settings.arabic_font), FLOOR_PX, 200,
                            rtl=True, by_word=True)
        self.right = TextBox(Fonts.arabic(self.win.settings.arabic_font), FLOOR_PX, 200,
                             rtl=True, by_word=True)
        self.size_the_boxes()
        lay.addWidget(self.parallel, 1)
        lay.addWidget(self.left, 1)
        lay.addWidget(self.right, 1)
        self.parallel.hide()

    @property
    def text_at(self) -> int:
        """Which of the three sizes is chosen: 0, 1 or 2, whatever the settings file holds."""
        at = getattr(self.win.settings, "text_step", 0)
        try:
            at = int(at)
        except (TypeError, ValueError):
            at = 0
        return max(0, min(at, len(TEXT_STEPS) - 1))

    @property
    def text_step(self) -> float:
        """How much larger than usual the Qur'an is set, from the A buttons on the bar."""
        return TEXT_STEPS[self.text_at]

    def size_the_boxes(self) -> None:
        """Hand the three text boxes the screen's scale and the chosen size, together.

        One number does both because the boxes already read `scale` for the smallest and the
        largest they may draw. Lifting it lifts the floor, which is what makes a page hold
        fewer verses, which is what makes the text come out bigger.
        """
        for w in (self.parallel, self.left, self.right):
            w.scale = self.win.s * self.text_step

    def set_text_step(self, at: int, keep_verse: int | None = None) -> None:
        """A different size was chosen. Lay the surah out again for it.

        [keep_verse] is an index into the surah to stay with. The pages fall in different
        places at a different size, so "page 4" means somewhere else afterwards; what the
        reader cares about is the verse in front of them, not the number of the page it is on.
        """
        self.win.settings.text_step = max(0, min(int(at), len(TEXT_STEPS) - 1))
        if keep_verse is None and self.pages:
            keep_verse = self.pages[max(0, min(self.at, len(self.pages) - 1))][0]
        self.size_the_boxes()
        self.at = 0
        self._measured = None
        self.repaginate()
        if keep_verse is not None:
            self.go_to(self.page_of(keep_verse))

    # What is being read

    def show_surah(self, verses: list[Verse], rtl_meaning: bool) -> None:
        self.verses = verses
        self.rtl_meaning = rtl_meaning
        self.face_the_meaning()
        self.at = 0
        self._measured = None
        self.repaginate()

    def face_the_meaning(self) -> None:
        """Set the meaning column in a face that HAS the letters it is about to draw.

        This was not being done at all. The column was built with the English family and left
        there, so a Chinese, Hindi or Bengali Qur'an was asked of a Latin face. Nothing looked
        wrong here, because a desktop has system fonts for all of them and Qt quietly borrows
        one -- which is the whole reason the mat carries its own: a Pi may have none, and what
        it cannot draw it draws as a box.

        The prayer screen has always chosen the face this way (see ui.py, Fonts.for_text on the
        lines about to be shown). The reader simply never did.

        Urdu is the exception the method already knew about: it is written in the Arabic script
        and takes the Arabic face, reading right to left.
        """
        said = "".join(v.meaning for v in self.verses[:40])
        face = (Fonts.arabic(self.win.settings.arabic_font) if self.rtl_meaning
                else Fonts.for_text(said))
        self.parallel.set_meaning_face(face, self.rtl_meaning)

    @property
    def translated(self) -> bool:
        return any(v.meaning for v in self.verses)

    @property
    def pages_count(self) -> int:
        return max(1, len(self.pages))

    # Where the pages fall

    def room(self) -> QtCore.QSize:
        return self.size()

    def repaginate(self) -> None:
        """Work out where each page starts and ends, for the room there is now."""
        key = (self.width(), self.height(), self.translated, len(self.verses),
               self.win.settings.arabic_font, self.win.s, self.text_step)
        if self._measured == key:
            return
        self._measured = key
        self.parallel.setVisible(self.translated)
        self.left.setVisible(not self.translated)
        self.right.setVisible(not self.translated)
        if not self.verses or self.width() < 50 or self.height() < 50:
            self.pages = [(0, len(self.verses))]
            self.show_page()
            self.turned.emit()
            return
        self.pages = list(self.walk())
        self.at = min(self.at, len(self.pages) - 1)
        self.show_page()
        # Where the pages fall is not known until the widget has a size, and a surah is often
        # opened before it has one. Saying so here is what keeps "page 1 of 8" from being the
        # answer to a question asked when the page was a few pixels tall.
        self.turned.emit()

    def walk(self):
        """Pages, one after another, each as full as it can be and still be readable."""
        start, total = 0, len(self.verses)
        while start < total:
            end = self.fits_from(start)
            yield (start, end)
            start = end

    def fits_from(self, start: int) -> int:
        """One past the last verse that fits on a page beginning at [start]. Never fewer than
        one: a verse too long for a whole page still has to be shown somewhere."""
        low, high = start + 1, min(len(self.verses), start + MOST_VERSES)
        if low >= high:
            return high if high > start else start + 1
        best = low
        while low <= high:
            mid = (low + high) // 2
            if self.holds(start, mid):
                best, low = mid, mid + 1
            else:
                high = mid - 1
        return best

    def holds(self, start: int, end: int) -> bool:
        floor = max(1, int(FLOOR_PX * self.win.s * self.text_step))
        some = self.verses[start:end]
        if self.translated:
            self.parallel.arabic = [self.numbered(v) for v in some]
            self.parallel.meaning = [v.meaning for v in some]
            self.parallel.meaning_rtl = self.rtl_meaning
            self.parallel._cache = None
            return self.parallel._rows(floor)[1] <= int(self.parallel.height() * 0.96)
        # Two Arabic columns: the right page, then the left. A page holds what both will take.
        half = (len(some) + 1) // 2
        for box, lines in ((self.right, some[:half]), (self.left, some[half:])):
            box.lines = [self.numbered(v) for v in lines]
            # measure_as_lines, not measure: see the note on it. Page breaks must not move
            # just because the words can now be lit one at a time.
            if box.lines and box.measure_as_lines(box.lines, floor) > int(box.height() * 0.92):
                return False
        return True

    @staticmethod
    def numbered(verse: Verse) -> str:
        """The verse with its number after it, in the Arabic way -- ﴿1﴾ closing the verse."""
        return f"{verse.arabic} ۝{verse.number}"

    # Showing one

    def show_page(self) -> None:
        if not self.pages:
            self.pages = [(0, len(self.verses))]
        start, end = self.pages[max(0, min(self.at, len(self.pages) - 1))]
        some = self.verses[start:end]
        if self.translated:
            self.parallel.set_lines([self.numbered(v) for v in some],
                                    [v.meaning for v in some], self.rtl_meaning)
        else:
            half = (len(some) + 1) // 2
            self.right.set_lines([self.numbered(v) for v in some[:half]])
            self.left.set_lines([self.numbered(v) for v in some[half:]])
        self.update()

    # Lighting a word

    def page_of(self, index: int) -> int | None:
        """Which page a verse falls on, so reciting can turn to it."""
        for i, (start, end) in enumerate(self.pages):
            if start <= index < end:
                return i
        return None

    def clear_highlight(self) -> None:
        self.parallel.set_highlight(None)
        self.left.set_highlight(None)
        self.right.set_highlight(None)

    def highlight_at(self, index: int, word: int | None) -> None:
        """Light word [word] of the verse at [index], wherever on the spread it has landed.

        With a translation there is one row per verse, so the row is the verse. Without, the
        page is split down the middle -- the right page first, then the left -- so which box
        holds the verse has to be worked out, and it is easy to get off by a half.
        """
        if word is None or not self.pages:
            return self.clear_highlight()
        start, end = self.pages[max(0, min(self.at, len(self.pages) - 1))]
        if not start <= index < end:
            return self.clear_highlight()
        row = index - start
        if self.translated:
            self.left.set_highlight(None)
            self.right.set_highlight(None)
            self.parallel.set_highlight((row, word))
            return
        self.parallel.set_highlight(None)
        half = (end - start + 1) // 2
        if row < half:
            self.right.set_highlight((row, word))
            self.left.set_highlight(None)
        else:
            self.left.set_highlight((row - half, word))
            self.right.set_highlight(None)

    def turn(self, forward: bool) -> bool:
        wanted = self.at + (1 if forward else -1)
        if not 0 <= wanted < len(self.pages):
            return False
        self.at = wanted
        self.show_page()
        self.turned.emit()
        return True

    def page_of(self, index: int) -> int:
        """Which page the verse at [index] has landed on."""
        for i, (start, end) in enumerate(self.pages):
            if start <= index < end:
                return i
        return max(0, len(self.pages) - 1)

    def go_to(self, page: int) -> None:
        self.at = max(0, min(page, len(self.pages) - 1))
        self.show_page()
        self.turned.emit()

    # Turning them

    def mousePressEvent(self, ev):
        self._down = ev.position().toPoint() if hasattr(ev, "position") else ev.pos()

    def mouseReleaseEvent(self, ev):
        if self._down is None:
            return
        here = ev.position().toPoint() if hasattr(ev, "position") else ev.pos()
        moved = here.x() - self._down.x()
        self._down = None
        if abs(moved) < int(SWIPE * self.win.s):
            return
        went_left = moved < 0
        self.turn(forward=(went_left == FORWARD_IS_LEFT))

    def resizeEvent(self, ev):
        self._measured = None
        self.repaginate()
        super().resizeEvent(ev)

    def follow_theme(self) -> None:
        for w in (self.parallel, self.left, self.right):
            w.update()


class Reader(QtWidgets.QWidget):
    """One surah, open: a bar saying where you are, and the two pages under it."""

    back = Signal()

    def __init__(self, window, quran: Quran):
        super().__init__()
        self.win = window
        self.quran = quran
        self.number = 1
        self.setObjectName("reader")
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(self.win.px(16), self.win.px(8), self.win.px(16), self.win.px(8))
        outer.setSpacing(self.win.px(8))

        bar = QtWidgets.QHBoxLayout()
        bar.setSpacing(self.win.px(12))
        self.back_button = QtWidgets.QPushButton(self.win.t("corner.back"))
        self.back_button.setObjectName("backButton")
        self.back_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.back_button.clicked.connect(self.back.emit)
        bar.addWidget(self.back_button)

        # The drawn play mark rather than the word "Recite": spelled out in six languages it
        # crowded the language buttons off the bar and clipped "Arabic only" to "abic on". It is
        # the same mark that sits beside every du'a, so one thing means play across the app.
        # The word is on the tooltip for anyone who wonders.
        self.recite_button = QtWidgets.QPushButton()
        self.recite_button.setObjectName("reciteButton")
        self.recite_button.setToolTip(self.win.t("quran.recite"))
        self.reciting_now = False
        self.draw_recite_mark()

        self.recite_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.recite_button.clicked.connect(self.toggle_reciting)
        bar.addWidget(self.recite_button)

        self.title = QtWidgets.QLabel()
        self.title.setObjectName("readerTitle")
        bar.addWidget(self.title)
        bar.addStretch(1)

        # There was a row of language buttons here -- "Arabic only", "English", "Français" and
        # the rest -- for setting the meaning beside the Arabic while reading. It has gone.
        #
        # It was a third place to answer a question the mat now asks once. Settings had a
        # language, Settings had a translation, and this bar had its own buttons, and all three
        # wrote to different places: the surah could be in French while the menu that opened it
        # was in Urdu. The page follows the mat's language now, and nothing has to be set to
        # make that happen -- which is also what makes "Arabic only" in Settings reach this
        # screen, where it opens the Arabic across both pages.
        #
        # The room it leaves goes to the title, which was being squeezed by seven buttons.
        self.buttons: dict[str, QtWidgets.QPushButton] = {}

        # Whose translation is on the page, in the room those buttons left behind. On the
        # screen the text itself is on, which is what a publisher asks for, and in the bar
        # rather than on the page, so it costs the reading not one line.
        #
        # It names the translation being SHOWN, so it changes with the mat's language and is
        # empty when there is no translation beside the Arabic -- an acknowledgement for a
        # translation nobody is reading would be worse than none.
        self.credit = QtWidgets.QLabel("")
        self.credit.setObjectName("readerCredit")
        self.credit.setAlignment(Qt.AlignmentFlag.AlignCenter)
        bar.addWidget(self.credit)
        bar.addStretch(1)

        # No volume slider here: the banner directly above this row has one, and two of them
        # a centimetre apart is one too many.

        # Which page you are on used to be spelled out beside the arrows. It has gone: the
        # arrows say the same thing by greying out at either end, and "Page 1 of 39" was the
        # widest thing in a row that had run out of room.
        # Pointing the way the reading goes: in Urdu and Arabic the pair mirrors to the
        # other side, so the heads turn with it. See ArrowButton in render.py.
        # How large the Qur'an is set, beside the arrows that turn the pages: the two things
        # you reach for with the page in front of you, in the one place you are already
        # looking. Before the arrows, so the pair that turns pages stays together at the end.
        # A size larger than it was drawn at. Not as large as the wu'du steps make it -- they
        # stand it beside two square buttons at the bottom of an open screen, where this sits
        # in a bar with a title, a play button and the page arrows, and a row as tall as a
        # button would push the bar down into the page.
        self.text_size = TextSize(self.win, getattr(self.win.settings, "text_step", 0),
                                  tall=READING_TEXT_SIZE_PX)
        self.text_size.chose.connect(self.resize_text)
        bar.addWidget(self.text_size, 0, Qt.AlignmentFlag.AlignVCenter)
        bar.addSpacing(self.win.px(18))
        self.earlier = ArrowButton(False, self.win.pack.rtl)
        self.later = ArrowButton(True, self.win.pack.rtl)
        for b, forward in ((self.earlier, False), (self.later, True)):
            b.setObjectName("turnPage")
            b.clicked.connect(lambda _=False, f=forward: self.spread.turn(f))
        bar.addWidget(self.earlier)
        bar.addWidget(self.later)
        outer.addLayout(bar)

        # Which verse is sounding. The only sign of it on the twelve verses whose words cannot
        # be lit, and a useful one on the rest.
        self.saying = QtWidgets.QLabel()
        self.saying.setObjectName("sayingVerse")
        bar.addWidget(self.saying)

        self.spread = Spread(self.win)
        self.spread.turned.connect(self.say_where)
        outer.addWidget(self.spread, 1)

        # Reciting state. at_verse is an index into the surah, not a verse number.
        self.reciting = False
        self.at_verse = 0
        self.waiting = False            # the recording has been asked for and is not here yet
        self.waited = 0.0               # seconds spent waiting for it
        self.follow = QtCore.QTimer(self)
        self.follow.setInterval(50)     # often enough that a word lights when it is said
        self.follow.timeout.connect(self.tick)

    def open(self, number: int) -> None:
        if self.reciting:
            self.stop_reciting()
        self.number = number
        surah = self.quran.surah(number)
        if surah is not None:
            self.title.setText(f"{surah.number}. {surah.name} · {surah.arabic}")
        self.reload()

    def meaning_language(self) -> str:
        """Which meaning to set beside the Arabic: the mat's own language, or none.

        "" means no meaning, and the spread then opens the Arabic across BOTH pages instead of
        putting the meaning on the left -- which is what "Arabic only" in Settings comes down
        to by the time it reaches this screen. The Qur'an has no Arabic translation of itself,
        so asking for the meaning in Arabic is asking for no meaning.
        """
        from .ui import ARABIC_ONLY
        lang = self.win.settings.lang
        if lang == ARABIC_ONLY or lang not in self.quran.languages():
            return ""
        return lang

    def reload(self) -> None:
        lang = self.meaning_language()
        self.spread.show_surah(self.quran.verses(self.number, lang), rtl_meaning=(lang in RTL))
        self.say_credit(lang)
        self.say_where()

    def say_credit(self, lang: str) -> None:
        """Name whoever made the translation on the page, or say nothing at all.

        Read off the text that is installed rather than from a list here, so a family that has
        put their own translation on the mat is shown that translation's credit. A translation
        with no source recorded says nothing here -- the Sources page is where a gap is
        reported, and a bar is no place to raise it.
        """
        from . import sources
        credit = sources.for_translation(self.quran, lang) if lang else None
        self.credit.setText(credit.who if credit is not None else "")

    def match_buttons(self) -> None:
        """Make the play button the same size as Back beside it.

        Done here rather than in the stylesheet because it cannot be written there: "Back" is
        Retour in French and Volver in Spanish, so Back's width is only known once it has been
        styled and laid out, while the glyph is always one character wide. Setting it at build
        time did nothing at all -- the stylesheet had not been applied yet, so it matched a
        size that was about to change.
        """
        wanted = self.back_button.size()
        if wanted.width() > 0:
            # Twice as tall as Back, and square, so the mark inside it can double. Matching
            # Back exactly is what kept it small.
            big = QtCore.QSize(wanted.height() * 2, wanted.height() * 2)
            if self.recite_button.size() != big:
                self.recite_button.setFixedSize(big)
                self.draw_recite_mark()

    def draw_recite_mark(self) -> None:
        """Redraw the mark at the button's size and the theme's ink."""
        from .ui import play_icon
        from .theme import palette
        # The mark keeps its share of the button; the button is what doubled, so the mark
        # doubles with it. Scaling both would draw an icon larger than the square it sits in,
        # and Qt would quietly crop it.
        side = max(self.win.px(30), int(self.recite_button.height() * 0.62))
        icon = play_icon(side, palette().ink, stop=self.reciting_now)
        self.recite_button.setIcon(QtGui.QIcon(icon))
        self.recite_button.setIconSize(icon.size())

    def showEvent(self, ev):
        super().showEvent(ev)
        self.match_buttons()

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self.match_buttons()

    def follow_scale(self) -> None:
        """The window changed size and has just been restyled. Catch up with it.

        Two things on this screen are sized FROM other widgets rather than from the
        stylesheet, so neither can be right until the stylesheet has been applied and laid
        out: the play button, which is twice the height of Back beside it, and the text boxes,
        whose floor and ceiling are the screen's scale times the chosen size.

        resizeEvent alone is not enough and was the bug. The scale change is noticed in
        MainWindow.resizeEvent and the restyle is deferred to the next turn of the event loop,
        so by the time Back is its new height every resizeEvent has already been and gone --
        the play button went on sitting at twice the height Back used to be, which at 1280 was
        a 114-pixel circle beside a 37-pixel button.
        """
        self.spread.size_the_boxes()
        self.spread._measured = None
        self.match_buttons()
        self.spread.repaginate()
        self.say_where()

    def resize_text(self, at: int) -> None:
        """One of the three A's was touched.

        The page is laid out again at the new size and the setting written down, so the mat
        opens the next surah -- and starts up tomorrow -- at the size it was left at. Someone
        who needs the big one needs it every time.
        """
        self.spread.set_text_step(at, self.at_verse if self.reciting else None)
        # The buttons are told as well as asked, so the red one is always the size the page is
        # actually set at -- including when something other than a finger changes it.
        self.text_size.set_at(self.spread.text_at)
        self.say_where()
        self.win.persist()

    def say_where(self) -> None:
        """Only the arrows now: live while there is a page that way, greyed out at the end."""
        self.earlier.setEnabled(self.spread.at > 0)
        self.later.setEnabled(self.spread.at < self.spread.pages_count - 1)

    def turn(self, forward: bool) -> bool:
        """The ring button and the arrow keys turn pages too, not only a finger."""
        return self.spread.turn(forward)

    # Reciting

    def can_recite(self) -> bool:
        return (self.win.recitation.available
                and self.win.word_times.known(self.number))

    def toggle_reciting(self) -> None:
        self.stop_reciting() if self.reciting else self.start_reciting()

    def start_reciting(self) -> None:
        """Begin at the top of the page being looked at, not at the top of the surah: somebody
        on page nine of Al-Baqarah wants to hear page nine."""
        if not self.spread.verses:
            return
        if not self.can_recite():
            self.saying.setText(self.win.t("quran.cannot_recite"))
            return
        start, _end = self.spread.pages[max(0, min(self.spread.at, len(self.spread.pages) - 1))]
        self.reciting = True
        self.at_verse = start
        self.reciting_now = True
        self.draw_recite_mark()
        self.recite_button.setToolTip(self.win.t("quran.stop_reciting"))
        self.begin_verse()
        self.follow.start()

    def stop_reciting(self, said: str = "") -> None:
        """Stop, and leave [said] in the bar. Stopping used to clear the bar unconditionally,
        which wiped the very message explaining why it had stopped -- so it reads what it is
        told to read, and the default is nothing."""
        self.follow.stop()
        self.reciting = False
        self.waiting = False
        self.win.recitation.stop()
        self.spread.clear_highlight()
        self.saying.setText(said)
        self.reciting_now = False
        self.draw_recite_mark()
        self.recite_button.setToolTip(self.win.t("quran.recite"))

    def begin_verse(self) -> None:
        """Ask for this verse's recording and the few after it, and play as soon as it lands."""
        verses = self.spread.verses
        if not 0 <= self.at_verse < len(verses):
            return self.stop_reciting()
        page = self.spread.page_of(self.at_verse)
        if page is not None and page != self.spread.at:
            self.spread.go_to(page)          # turn to the verse being recited
        number = verses[self.at_verse].number
        self.saying.setText(f"{self.number}:{number}")
        soon = [(self.number, verses[i].number)
                for i in range(self.at_verse, min(len(verses), self.at_verse + 4))]
        self.win.verses.want(soon)
        self.waiting = True
        self.waited = 0.0
        self.play_now()

    def play_now(self) -> bool:
        """Play the verse if its recording is here. Quietly does nothing if it is not yet."""
        verses = self.spread.verses
        number = verses[self.at_verse].number
        if not self.win.verses.have(self.number, number):
            if self.win.verses.gave_up_on(self.number, number) or self.waited >= PATIENCE:
                self.stop_reciting(self.win.t("quran.cannot_recite"))
            return False
        self.waiting = False
        path = self.win.verses.path_for(self.number, number)
        if not self.win.recitation.play(path, Span(0.0, WHOLE)):
            self.stop_reciting(self.win.t("quran.cannot_recite"))
            return False
        return True

    def tick(self) -> None:
        """Fifty times a second: light the word being said, and move on at the end of a verse."""
        if not self.reciting:
            return
        if self.waiting:
            self.waited += self.follow.interval() / 1000.0
            self.play_now()
            return
        position = self.win.recitation.position()
        if position is None and not self.win.recitation.busy:
            self.at_verse += 1              # that verse is done; on to the next
            self.spread.clear_highlight()
            if self.at_verse >= len(self.spread.verses):
                return self.stop_reciting()
            return self.begin_verse()
        if position is None:
            return
        self.keep_up()
        number = self.spread.verses[self.at_verse].number
        if self.win.word_times.whole_only(self.number, number):
            # One of the twelve where the two texts disagree about where a word ends. Lighting
            # a word here would light the wrong one, so none is lit and the bar says the verse.
            self.spread.clear_highlight()
            return
        word = self.win.word_times.word_at(self.number, number, position)
        self.spread.highlight_at(self.at_verse, word)

    def keep_up(self) -> None:
        """Turn the page when the recitation leaves it.

        Without this the reciter walks off the bottom of the page and the lighting simply
        stops, because highlight_at only lights a verse that is on the page in front of you --
        so the listener has to turn pages by hand to keep up with a recording. That was just
        about livable when a surah was a few pages; with the text set large Ya-Sin is thirty
        four, and it would be the whole of the experience.

        Only while reciting. Someone reading at their own pace, who has turned back a page to
        look at something, should not be dragged forward.
        """
        if not self.reciting:
            return
        wanted = self.spread.page_of(self.at_verse)
        if wanted != self.spread.at:
            self.spread.go_to(wanted)

    def follow_theme(self) -> None:
        self.spread.follow_theme()
