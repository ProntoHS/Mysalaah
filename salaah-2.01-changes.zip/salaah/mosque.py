"""The main screen: the mosque, with an arch for each prayer.

On a dark screen the drawing is turned over: a white mosque on a black sky, the time in black on
the white dome. The time sits in white on the dome, and whichever prayer's time it is has its arch lit up. Tap an
arch to start that prayer.
"""
from __future__ import annotations

import json
import math
import random
import sys
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from .qt import QtCore, QtGui, QtWidgets, Qt, Signal
from .theme import palette

GREEN = QtGui.QColor("#1E9E57")            # the name of the prayer whose time it is
GREEN_DARK = QtGui.QColor("#4CD187")       # the same, on a dark screen
NAME_BAND = (0.58, 0.98)                   # where a drawn-in name sits in its arch, as
                                           # fractions of the panel's height. Measured across
                                           # all ten of Harry's drawings: the lettering runs
                                           # from 0.610 (Hindi) to 0.971 (Urdu and Arabic), and
                                           # the panel is solid black right across the box from
                                           # 0.58 down to 0.98. Above that the box takes in the
                                           # white wall beside the arch's curve.
CLOCK_INK = QtGui.QColor("white")          # on the black dome; black on the white one after dark
CLOCK_BOOST = 1.15                         # the time, this much larger than a plain fit
CLOCK_TRIM = 0.95                          # and then this much smaller again, as asked for.
                                           # 0.85 until 1.67, when Harry asked for the time
                                           # on the dome "slightly bigger" again.
CLOCK_WEIGHT = 0.05                        # the time's strokes thickened by this much of its
                                           # own height, which is how it is made bolder.
                                           # Not by asking for a heavier weight: the face the
                                           # mat falls back to has Regular and Bold and
                                           # nothing above, so 800 and 900 draw exactly what
                                           # 700 draws -- measured, 10,424 dark pixels for
                                           # all three. Stroking the lettering works in any
                                           # face, including whichever one a Pi happens to
                                           # have, and is the same thickening at every size.
CLOCK_LIFT = 0.07                          # and this much of the box's height higher up
CLOCK_ROOM = 0.35                          # room either side, so a boosted digit is never clipped
SUN = QtGui.QColor(255, 193, 7)
MOON = QtGui.QColor(232, 233, 228)
MOON_EDGE = QtGui.QColor(120, 124, 130)
STARS = 22                                 # twinkling in the night sky
BIRDS = 4                                  # fluttering across by day
SKY_STEP = 200                             # milliseconds between frames: gentle, and cheap


class GearButton(QtWidgets.QWidget):
    """A settings cog, drawn rather than lettered, so it needs no icon font."""
    pressed_signal = Signal()

    def __init__(self, size: int, colour: QtGui.QColor | None = QtGui.QColor("white")):
        super().__init__()
        self.colour = colour          # None: the theme's ink, black by day and white after dark
        self.setFixedSize(size, size)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def paintEvent(self, _):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        middle = QtCore.QPointF(self.width() / 2, self.height() / 2)
        radius = min(self.width(), self.height()) / 2 * 0.94

        tooth = QtGui.QPainterPath()
        tooth.addRoundedRect(QtCore.QRectF(-radius * 0.17, -radius, radius * 0.34, radius * 2),
                             radius * 0.07, radius * 0.07)
        gear = QtGui.QPainterPath()
        for i in range(4):     # four bars crossing gives eight teeth
            spin = QtGui.QTransform().translate(middle.x(), middle.y()).rotate(i * 45)
            gear = gear.united(spin.map(tooth))
        body = QtGui.QPainterPath()
        body.addEllipse(middle, radius * 0.68, radius * 0.68)
        gear = gear.united(body)
        hole = QtGui.QPainterPath()
        hole.addEllipse(middle, radius * 0.30, radius * 0.30)

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(self.colour if self.colour is not None else QtGui.QColor(palette().ink))
        painter.drawPath(gear.subtracted(hole))

    def mouseReleaseEvent(self, event):
        if self.rect().contains(event.position().toPoint()):
            self.pressed_signal.emit()


class ArchButton(QtWidgets.QWidget):
    """One arch, drawn from the shape taken off the artwork, with its own number and label.

    Drawn rather than pictured, so a prayer can have as many arches as it has units and each
    can say what it is. Tapping it chooses that unit.
    """
    chosen = Signal(object)

    def colours(self) -> tuple[QtGui.QColor, QtGui.QColor, QtGui.QColor]:
        """The panel, the outline and the lettering.

        Straight off the theme rather than shades of its own, so the arch is an outline on the
        page it sits on - white inside by day, black inside after dark - and it can never drift
        out of step with the screen around it. The panel is still painted rather than left
        clear: it covers whatever is behind, which is what lets the walk into the arch dissolve
        into these.
        """
        colours = palette()
        return (QtGui.QColor(colours.paper), QtGui.QColor(colours.ink),
                QtGui.QColor(colours.ink))

    def __init__(self, shape: "ArchShape", count: str, label: str, payload, family: str = ""):
        super().__init__()
        self.shape = shape
        self.count = count
        self.label = label
        self.payload = payload
        self.family = family
        self.pressed = False
        self._drawn: QtGui.QPixmap | None = None
        self._drawn_dark = False
        self.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding, QtWidgets.QSizePolicy.Policy.Expanding)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    @property
    def aspect(self) -> float:
        return self.shape.aspect

    def resizeEvent(self, _):
        self._drawn = None

    PAD = 0.03     # so the arch's base line is never clipped
    PAD_X = 0.04   # and a little clear either side, so neighbouring arches never touch

    def arch_rect(self) -> QtCore.QRect:
        """The arch, as large as fits, centred in the widget."""
        room_h = int(self.height() * (1 - 2 * self.PAD))
        room_w = int(self.width() * (1 - 2 * self.PAD_X))
        width = min(room_w, int(room_h * self.aspect))
        height = int(width / self.aspect)
        return QtCore.QRect((self.width() - width) // 2, (self.height() - height) // 2,
                            width, height)

    def paintEvent(self, _):
        box = self.arch_rect()
        if box.width() < 4 or box.height() < 4:
            return
        panel, border, text = self.colours()
        if self._drawn is None or self._drawn_dark != palette().dark:
            self._drawn = self.shape.draw(box.size(), panel, border)
            self._drawn_dark = palette().dark
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.SmoothPixmapTransform)
        if self.pressed:
            painter.setOpacity(0.75)
        painter.drawPixmap(box.topLeft(), self._drawn)
        painter.setOpacity(1.0)

        # The number sits in the belly of the arch, the label under it.
        painter.setPen(text)
        number_font = QtGui.QFont(self.family) if self.family else painter.font()
        number_font.setPixelSize(max(10, int(box.height() * 0.26)))
        number_font.setWeight(QtGui.QFont.Weight(700))
        painter.setFont(number_font)
        top = QtCore.QRect(box.x(), box.y() + int(box.height() * 0.22), box.width(), int(box.height() * 0.30))
        painter.drawText(top, int(Qt.AlignmentFlag.AlignCenter), self.count)

        # The label is as large as fits between the arch's sides, so "Sunnah" is never clipped.
        bottom = QtCore.QRect(box.x() + int(box.width() * 0.08),
                              box.y() + int(box.height() * 0.58),
                              int(box.width() * 0.84), int(box.height() * 0.26))
        label_font = QtGui.QFont(self.family) if self.family else painter.font()
        label_font.setWeight(QtGui.QFont.Weight(700))
        size = max(8, int(box.height() * 0.17))
        label_font.setPixelSize(size)
        while size > 8 and QtGui.QFontMetrics(label_font).horizontalAdvance(self.label) > bottom.width():
            size -= 1
            label_font.setPixelSize(size)
        painter.setFont(label_font)
        painter.drawText(bottom, int(Qt.AlignmentFlag.AlignCenter), self.label)

    def mousePressEvent(self, _):
        self.pressed = True
        self.update()

    def mouseReleaseEvent(self, event):
        self.pressed = False
        self.update()
        if self.rect().contains(event.position().toPoint()):
            self.chosen.emit(self.payload)


class ArchShape:
    """The arch outline and the panel inside it, ready to be drawn at any size."""

    def __init__(self, assets: Path):
        folder = assets / "mosque"
        self.outer = QtGui.QImage(str(folder / "arch-outer.png"))
        self.inner = QtGui.QImage(str(folder / "arch-inner.png"))
        self._cache: dict[tuple[int, int, str, str], QtGui.QPixmap] = {}

    @property
    def ready(self) -> bool:
        return not self.outer.isNull() and not self.inner.isNull()

    @property
    def aspect(self) -> float:
        return self.outer.width() / self.outer.height() if self.ready else 0.68

    KEEP = 8        # how many sizes to remember; a resize or a theme change makes new ones

    def draw(self, size: QtCore.QSize, panel: QtGui.QColor,
             border: QtGui.QColor) -> QtGui.QPixmap:
        key = (size.width(), size.height(), panel.name(), border.name())
        if key not in self._cache:
            picture = QtGui.QPixmap(size)
            picture.fill(Qt.GlobalColor.transparent)
            painter = QtGui.QPainter(picture)
            for mask, colour in ((self.outer, border), (self.inner, panel)):
                # The mask is shrunk to size first and the colour put on afterwards. Colouring
                # first would mean shrinking a picture four times the weight for the same
                # result, which the Pi feels. The shrinking is what smooths the edge.
                small = mask.scaled(size, Qt.AspectRatioMode.IgnoreAspectRatio,
                                    Qt.TransformationMode.SmoothTransformation)
                layer = QtGui.QImage(small.size(), QtGui.QImage.Format.Format_ARGB32)
                layer.fill(colour)
                layer.setAlphaChannel(small.convertToFormat(QtGui.QImage.Format.Format_Grayscale8))
                painter.drawImage(0, 0, layer)
            painter.end()
            if len(self._cache) >= self.KEEP:
                self._cache.clear()
            self._cache[key] = picture
        return self._cache[key]


class ZoomVeil(QtWidgets.QWidget):
    """Walks into the arch: the mosque swells towards the arch that was tapped and fades out,
    leaving the prayer's own arches behind it.

    It is only a picture laid over the top. The screen underneath has already changed before
    this starts, so if it is cut short, or never runs at all, nothing is left half done - the
    worst that happens is that the change is instant. That matters on a mat: an animation is
    never allowed to be the thing that decides which screen you are on.

    The picture is taken once, at half size, and blown up without smoothing. Nothing stands
    still long enough to see the difference, and it saves the Pi three quarters of the work on
    every frame.
    """
    finished = Signal()

    MS = 1000           # how long the walk takes
    STEP = 33           # milliseconds a frame: about 30 a second, which is plenty this quick
    ZOOM = 2.8          # how much nearer the arch ends up
    DISSOLVE = 0.45     # the last of the walk over which the mosque thins away
    COARSE = 2          # the picture is taken at one part in this of full size

    def __init__(self, parent):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.picture = QtGui.QPixmap()
        self.focus = QtCore.QPointF()
        self.began = 0.0
        self.timer = QtCore.QTimer(self)
        self.timer.setInterval(self.STEP)
        self.timer.timeout.connect(self.tick)
        self.hide()

    def start(self, shot: QtGui.QPixmap, area: QtCore.QRect, focus: QtCore.QPoint) -> None:
        """Walks into the point [focus] of [shot], a picture of the screen as it was a moment
        ago, laid over [area]. The picture is taken by the caller, before the screen changes."""
        if shot.isNull() or area.width() < 8 or area.height() < 8:
            return self.give_up()
        self.picture = shot.scaled(shot.size() / self.COARSE,
                                   Qt.AspectRatioMode.IgnoreAspectRatio,
                                   Qt.TransformationMode.SmoothTransformation)
        self.focus = QtCore.QPointF(focus) / self.COARSE
        self.setGeometry(area)
        self.began = time.monotonic()
        self.show()
        self.raise_()
        self.timer.start()
        self.update()

    def give_up(self) -> None:
        """Nothing to show: say it is over, so whoever is waiting carries on regardless."""
        self.stop()

    def stop(self) -> None:
        if self.timer.isActive():
            self.timer.stop()
        self.picture = QtGui.QPixmap()
        self.hide()
        self.finished.emit()

    @property
    def running(self) -> bool:
        return self.timer.isActive()

    def how_far(self) -> float:
        """How far through the walk, nought to one.

        It builds and then eases off, rather than starting at full pelt: a step that begins
        fast reads as a jolt, where a walk towards something gathers pace.
        """
        gone = (time.monotonic() - self.began) * 1000 / self.MS
        step = min(1.0, max(0.0, gone))
        return step * step * (3 - 2 * step)

    def tick(self) -> None:
        if self.how_far() >= 1.0:
            return self.stop()
        self.update()

    def frame(self, along: float) -> tuple[QtCore.QRectF, float]:
        """Where the picture goes this frame, and how solid it is.

        The arch drifts from where it was tapped to the middle of the screen while everything
        swells around it, which is what reading as walking towards it depends on. It thins out
        late, so the mosque is still there for most of the move.
        """
        grown = 1 + (self.ZOOM - 1) * along
        middle = QtCore.QPointF(self.width() / 2, self.height() / 2)
        here = QtCore.QPointF(self.focus.x() * self.COARSE, self.focus.y() * self.COARSE)
        aim = here + (middle - here) * along
        wide, tall = self.picture.width() * self.COARSE, self.picture.height() * self.COARSE
        box = QtCore.QRectF(aim.x() - self.focus.x() * self.COARSE * grown,
                            aim.y() - self.focus.y() * self.COARSE * grown,
                            wide * grown, tall * grown)
        return box, max(0.0, min(1.0, (1 - along) / self.DISSOLVE))

    def paintEvent(self, _):
        if self.picture.isNull():
            return
        box, solid = self.frame(self.how_far())
        painter = QtGui.QPainter(self)
        painter.setClipRect(self.rect())        # no work on the part that has left the screen
        painter.setOpacity(solid)
        painter.drawPixmap(box, self.picture, QtCore.QRectF(self.picture.rect()))


class Sky:
    """What moves in the sky behind the mosque: stars that twinkle after dark, birds that
    flutter across by day. Everything is held as fractions of the picture, so it lands in the
    same place whatever the screen size, and is drawn behind the mosque."""

    def __init__(self, seed: int = 7):
        chance = random.Random(seed)
        # Stars sit in the upper part of the sky, away from the very edges.
        self.stars = [(chance.uniform(0.04, 0.96), chance.uniform(0.04, 0.46),
                       chance.uniform(0.6, 1.0), chance.uniform(0, 6.28))
                      for _ in range(STARS)]
        # Birds: where they start, how fast they drift, how high, how fast they flap.
        self.birds = [(chance.uniform(0, 1), chance.uniform(0.012, 0.022),
                       chance.uniform(0.10, 0.32), chance.uniform(0, 6.28))
                      for _ in range(BIRDS)]

    @staticmethod
    def now() -> float:
        return time.monotonic()

    def star_alpha(self, twinkle: float, phase: float, moment: float) -> int:
        """How bright a star is just now: a slow breath in and out, each on its own beat."""
        wave = (math.sin(moment * 1.6 + phase) + 1) / 2
        return int(90 + 160 * twinkle * wave)

    def bird_at(self, bird, moment: float) -> tuple[float, float, float]:
        """Where a bird is, as fractions across and down, and how far through a wingbeat."""
        start, speed, height, phase = bird
        across = (start + moment * speed) % 1.25 - 0.12     # off one side, back on the other
        up_down = height + 0.012 * math.sin(moment * 0.9 + phase)
        return across, up_down, math.sin(moment * 7.0 + phase)


@dataclass(frozen=True)
class Arch:
    """One arch: what it is called in the drawing, and where it sits in the picture.

    It used to carry a mask of its inside as well, for lifting the lettering off the artwork.
    Nothing reads one any more -- see the note where name_in_green used to be -- so the
    arch-<name>.png files beside a drawing are no longer opened.
    """
    prayer: str
    box: QtCore.QRect


# The artwork, kept once instead of once per screen. There are three mosques now -- the front
# door, the five prayers and the six kalima -- and every settings change rebuilds all of them,
# so without this a change of language throws away and re-reads about twenty megabytes of
# picture. QPixmap and QImage are shared inside Qt, so handing the same one to several screens
# costs nothing; everything that uses them here takes a copy before touching them.
_ARTWORK: dict = {}


def _load_once(path: Path, as_image: bool = False):
    """The picture at this path, read from disk the first time and remembered after.

    Keyed by the file's modification time as well as its name, so rebuilding the artwork while
    the app is running picks up the new drawing rather than the old one.
    """
    try:
        stamp = path.stat().st_mtime_ns
    except OSError:
        stamp = 0
    key = (str(path), stamp, as_image)
    if key not in _ARTWORK:
        _ARTWORK[key] = QtGui.QImage(str(path)) if as_image else QtGui.QPixmap(str(path))
    return _ARTWORK[key]


class MosqueScreen(QtWidgets.QWidget):
    """Draws the mosque to fit, and turns taps on an arch into a prayer."""
    chosen = Signal(str)

    def __init__(self, assets: Path, clock_font: str = "", folder: str = "mosque",
                 idle_glow: bool = True, anywhere: bool = False,
                 lang: str = "en", rtl: bool = False):
        super().__init__()
        # The language the mat is set to, and whether it is read right to left. Both are only
        # read while loading: a change of language restarts the app, so there is no case where
        # one of these changes under a screen that is already up.
        self.lang = lang or "en"
        self.rtl = bool(rtl)
        # Whether a touch that lands on no arch counts as a touch on the first one. Off for a
        # menu, where the arches are the choice and the sky between them means nothing. On for
        # the front door, which is a way in rather than a choice: Harry asked for the whole
        # screen, so a finger on a palm tree opens it the same as a finger on the name.
        self.anywhere = anywhere
        # Which drawing this is. Nothing about the screen is specific to the five prayers: it is
        # a picture, a box for the clock, and a box per arch, so the six kalima get the same
        # front door by pointing this at their own folder.
        self.folder = folder
        # The main screen glows its minarets when no prayer is due, meaning "nothing to pray
        # just now". On a menu of things to read that would be saying something untrue, so it
        # can be turned off.
        self.idle_glow = idle_glow
        self.arches: list[Arch] = []
        # Which screen the artwork was drawn for. The first mosque was dark ink on a light
        # ground and is turned inside out after dark; the ones drawn since are white lines on
        # black and are shown as they are, and turned inside out by day instead. The drawing
        # says which it is, so the two kinds can sit side by side.
        self.drawn_dark = False
        self.picture = QtGui.QPixmap()
        # A drawing that moves, if the folder has one beside the still. The still is still what
        # the arch boxes and the clock box were measured on, so the two have to be the same
        # canvas -- load() checks that rather than trusting it.
        self.film: QtGui.QMovie | None = None
        self._frame: QtGui.QPixmap | None = None
        self._frame_key: tuple = ()
        self.clock_box = QtCore.QRect()
        # What goes inside each arch: the number of units and what kind they are. Empty on the
        # drawings whose arches say their own names; filled on the five prayer pages, whose
        # drawings had their words taken out at build time precisely so these could be in the
        # language the mat is set to. See tools/build_prayer_pages.py for why.
        self.labels: dict[str, tuple[str, str]] = {}
        # Whether this drawing carries its own words in its arches. The front page did not
        # between 1.63 and 1.83 -- the app wrote the five names into empty arches -- and does
        # again from 1.84, because Harry drew the mosque ten times over, once per language,
        # with the names printed in. When the drawing has them, the app must not write them
        # too, and the prayer whose time it is is shown by tinting the word he drew rather than
        # by writing a green one. The drawing says which it is.
        self.own_names = False
        self.label_face = ""
        # Where in an arch those two lines sit, as fractions of its height, measured off the
        # drawing by the builder so the app puts the words back where they were drawn.
        self.bands = {"number": (0.32, 0.59), "label": (0.70, 0.88)}
        # Whether the app paints a sky behind this drawing. The first two mosques are outlines
        # with a see-through sky, so the app supplies the sun, the moon, the stars and the
        # birds. The front door brings its own, all of them moving, and painting a second moon
        # beside the one already drawn would be worse than painting none -- so the drawing
        # says, and when it says no, the sky is not drawn and its clock is not run.
        self.own_sky = True
        # Whether the numbers on the dome are dark. An outline dome is a hole in the picture
        # and takes light numbers; a solid one takes dark. Both flip with the artwork.
        self.clock_dark = False
        self.lit: str | None = None
        self.minarets: dict[str, QtCore.QRect] = {}
        self.sun_up = True
        self.sky = Sky()
        self.flutter = QtCore.QTimer(self)      # only while the main screen is on show
        self.flutter.setInterval(SKY_STEP)
        self.flutter.timeout.connect(self.update)
        self.through = 0.5      # how far across the sky the sun or moon has travelled
        self.time_text = ""
        self.clock_font = clock_font
        self._scaled: QtGui.QPixmap | None = None
        self._scaled_dark = False
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent)
        self.load(assets)

    # Loading

    def load(self, assets: Path) -> None:
        folder = assets / self.folder
        try:
            described = json.loads((folder / "mosque.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        self.picture = _load_once(folder / self.drawing_for(described, self.lang))
        self.own_names = described.get("names") == "drawn"
        self.drawn_dark = described.get("drawn", "light") == "dark"
        self.own_sky = bool(described.get("sky", True))
        self.load_film(folder / "mosque.gif")      # after own_sky: the film is checked against it
        for which, band in described.get("text", {}).items():
            if which in self.bands and len(band) == 2:
                self.bands[which] = (float(band[0]), float(band[1]))
        box = described["clock"]["box"]
        self.clock_dark = described["clock"].get("ink", "light") == "dark"
        self.clock_box = QtCore.QRect(box[0], box[1], box[2] - box[0], box[3] - box[1])
        for side, box in described.get("minarets", {}).items():
            self.minarets[side] = QtCore.QRect(box[0], box[1], box[2] - box[0], box[3] - box[1])
        for prayer, arch in described["arches"].items():
            x0, y0, x1, y1 = arch["box"]
            self.arches.append(Arch(prayer, QtCore.QRect(x0, y0, x1 - x0, y1 - y0)))
        self.face_the_other_way()

    @staticmethod
    def drawing_for(described: dict, lang: str) -> str:
        """Which drawing of this mosque to show, for the language the mat is set to.

        The same idea as the menus (see FilmSheet.sheet_for): Harry drew the front of the
        mosque once per language, with the five prayer names printed in the arches, so the
        words are part of the picture rather than lettering laid over it. The BOXES are not per
        language -- every drawing is the same canvas with the same arches in the same places,
        and there is a test that measures that rather than taking my word for it.

        A language with no drawing of its own, and the two screens that have one drawing
        between them -- the kalima menu and the five prayer pages -- fall back to "image".
        """
        drawings = described.get("images") or {}
        return drawings.get(lang) or drawings.get("en") or described["image"]

    def face_the_other_way(self) -> None:
        """In Urdu and Arabic the arches run right to left, so the names belong to other boxes.

        Harry drew it that way: on his Urdu mosque فجر is in the RIGHTMOST arch and عشاء in the
        leftmost, which is how the five would be read. The boxes do not move -- they are where
        the panels are -- so the prayer each box belongs to is what turns round, and with it
        which arch lights up and which prayer a finger on it opens. Leaving this out would have
        shown Fajr's name on the right and opened Isha when it was pressed.

        Only where the drawing carries its own names: the five prayer pages number rakats in
        arches of their own, and 1, 2, 3, 4 is not a thing to reverse.
        """
        if not (self.rtl and self.own_names) or len(self.arches) < 2:
            return
        names = [arch.prayer for arch in self.arches]
        boxes = sorted((arch.box for arch in self.arches), key=lambda b: b.x())
        self.arches = [Arch(prayer, box) for prayer, box in zip(names, reversed(boxes))]

    def load_film(self, path: Path) -> None:
        """The moving version of this drawing, if there is one and it fits the still.

        Refused if the two are different sizes: every box on this screen -- the arches, the
        clock -- was measured against the still, so a film on a different canvas would put the
        picture and the places you can touch out of step with each other.

        Refused too if the drawing wants an app-painted sky and the film has none of its own.
        The sky is painted first and the film over it, so a film with a solid black rectangle
        where the sky should be would bury the sun, the moon and every star behind it. The
        builder cuts the sky out of every frame; this is what notices when it has not.
        """
        if not path.is_file():
            return
        movie = QtGui.QMovie(str(path))
        if not movie.isValid() or movie.frameCount() < 2:
            return
        movie.jumpToFrame(0)
        if movie.currentPixmap().size() != self.picture.size():
            print(f"{path.name}: {movie.currentPixmap().size().width()}x"
                  f"{movie.currentPixmap().size().height()} does not match the still "
                  f"({self.picture.width()}x{self.picture.height()}); showing the still",
                  file=sys.stderr)
            return
        if self.own_sky and not movie.currentPixmap().hasAlphaChannel():
            print(f"{path.name}: no see-through sky, and this drawing has the app paint one; "
                  f"showing the still", file=sys.stderr)
            return
        movie.setParent(self)
        movie.frameChanged.connect(self.next_frame)   # a bound method: Qt drops it with us
        self.film = movie

    def next_frame(self, _frame: int) -> None:
        self.update()

    def film_frame(self, size: QtCore.QSize, flip: bool):
        """This frame of the film, at the size the still is drawn, or None.

        Kept from one paint to the next and worked out again only when the frame, the size or
        the theme changes. The stars twinkle far faster than the film moves, so without this
        every one of those repaints would rescale a one-and-a-half megapixel picture.
        """
        if self.film is None:
            return None
        key = (self.film.currentFrameNumber(), size.width(), size.height(), flip)
        if key != self._frame_key or self._frame is None:
            frame = self.film.currentPixmap()
            if frame.isNull():
                return None
            frame = frame.scaled(size, Qt.AspectRatioMode.IgnoreAspectRatio,
                                 Qt.TransformationMode.SmoothTransformation)
            if flip:
                from .render import invert
                frame = invert(frame)
            self._frame, self._frame_key = frame, key
        return self._frame

    @property
    def ready(self) -> bool:
        return not self.picture.isNull() and bool(self.arches)

    # What to show

    def set_dome(self, text: str) -> None:
        """What is written across the dome. The time on the front door and on the kalima menu;
        the prayer's own name, in the language the mat is set to, on the five prayer pages. One
        setter rather than two, because it is one piece of lettering in one box -- what it says
        is the caller's business."""
        if text != self.time_text:
            self.time_text = text
            self.update()

    def set_time(self, text: str) -> None:
        self.set_dome(text)

    def set_labels(self, labels: dict[str, tuple[str, str]], face: str = "") -> None:
        """The number and the kind inside each arch, keyed by the arch's name in the drawing."""
        if (labels, face) != (self.labels, self.label_face):
            self.labels, self.label_face = dict(labels), face
            self.update()

    def set_lit(self, prayer: str | None) -> None:
        """The prayer that may be prayed now. None lights the minarets instead: no prayer is due."""
        if prayer != self.lit:
            self.lit = prayer
            self.update()

    def set_sky(self, sun_up: bool, through: float) -> None:
        if (sun_up, round(through, 3)) != (self.sun_up, round(self.through, 3)):
            self.sun_up, self.through = sun_up, max(0.0, min(1.0, through))
            self.update()

    # Drawing

    @property
    def flipped(self) -> bool:
        """Whether the drawing is being shown inside out -- because the screen is not the one
        it was drawn for. Everything laid OVER the artwork keys off this rather than off the
        theme: what matters to the clock and the green name is whether the dome and the arch
        panel under them came out light or dark, not what colour the page is."""
        return palette().dark != self.drawn_dark

    def placement(self) -> tuple[QtGui.QPixmap, QtCore.QPoint, float]:
        """The picture scaled to fit, where it sits, and by how much it was scaled."""
        flip = self.flipped
        if self._scaled is None or self._scaled_dark != flip or (
                self._scaled.width() != self.width() and self._scaled.height() != self.height()):
            self._scaled = self.picture.scaled(self.size(), Qt.AspectRatioMode.KeepAspectRatio,
                                               Qt.TransformationMode.SmoothTransformation)
            if flip:
                from .render import invert
                self._scaled = invert(self._scaled)
            self._scaled_dark = flip
        scale = self._scaled.width() / self.picture.width()
        origin = QtCore.QPoint((self.width() - self._scaled.width()) // 2,
                               (self.height() - self._scaled.height()) // 2)
        return self._scaled, origin, scale

    def clock_type(self, box: QtCore.QRect, text: str,
                   fallback: QtGui.QFont | None = None) -> QtGui.QFont:
        """The time, as large as the dome allows: fitted to the flat middle of the dome, then
        CLOCK_BOOST larger again, since the dome curves out wider either side of the numbers,
        and CLOCK_TRIM smaller after that. The two are kept apart rather than multiplied into
        one number so the reason for each is still readable: the first is about the shape of a
        dome, the second is somebody looking at it and wanting the time a little smaller."""
        font = QtGui.QFont(self.clock_font) if self.clock_font else QtGui.QFont(fallback or QtGui.QFont())
        font.setWeight(QtGui.QFont.Weight(700))
        size = max(8, int(box.height() * 1.10))
        font.setPixelSize(size)
        while size > 8 and QtGui.QFontMetrics(font).horizontalAdvance(text) > box.width() * 0.94:
            size -= 2
            font.setPixelSize(size)
        font.setPixelSize(max(8, int(size * CLOCK_BOOST * CLOCK_TRIM)))
        return font

    def draw_the_time(self, painter: QtGui.QPainter, font: QtGui.QFont,
                      where: QtCore.QRect, ink: QtGui.QColor) -> None:
        """The time across the dome, drawn as a shape and then thickened.

        Centred in [where] by hand rather than by AlignCenter, because a letter drawn as a
        path is placed by its baseline and there is no alignment flag for a path. The centre
        of the lettering, not of the line: ascent less descent puts the digits' own middle on
        the middle of the box, where a plain half-the-line-height would hang them low by the
        depth of a descender the time has not got.

        Then stroked as well as filled, which is what makes it bolder -- see CLOCK_WEIGHT.
        """
        metrics = QtGui.QFontMetricsF(font)
        path = QtGui.QPainterPath()
        path.addText(where.center().x() - metrics.horizontalAdvance(self.time_text) / 2,
                     where.center().y() + (metrics.ascent() - metrics.descent()) / 2,
                     font, self.time_text)
        pen = QtGui.QPen(ink)
        pen.setWidthF(max(1.0, font.pixelSize() * CLOCK_WEIGHT))
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        painter.setPen(pen)
        painter.setBrush(ink)
        painter.drawPath(path)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(Qt.BrushStyle.NoBrush)

    def clock_rect(self, box: QtCore.QRect) -> QtCore.QRect:
        """Where the time is drawn: the dome's flat middle, lifted a little towards the centre
        of the dome, and given room either side so the boosted lettering is not clipped."""
        room = int(box.width() * CLOCK_ROOM)
        lift = int(box.height() * CLOCK_LIFT)
        return QtCore.QRect(box.x() - room, box.y() - lift, box.width() + 2 * room, box.height())

    # GONE IN 1.63: name_in_green, _stencil and glow_for.
    #
    # The prayer's name used to be part of the drawing, so showing the current one in green
    # meant lifting its lettering off the artwork pixel by pixel: fill each arch's mask row by
    # row, and whatever the filled shape covers but the mask does not is the word. It worked,
    # and it was forty lines of per-pixel Python to avoid the simple thing.
    #
    # The names are not in the drawing any more. Harry's new main page has empty arches and the
    # app writes the names in from the pack, in whatever language the mat is set to -- so the
    # green one is the word painted green, in draw_labels, and there is nothing to lift. The
    # masks those three read, arch-<prayer>.png, are no longer loaded either.
    #
    # glow_for went with them. It filled an arch with yellow and had not been called since the
    # yellow box over the lit arch was dropped; the only thing that mentioned it was a test
    # making sure it was not used.

    def sky_body(self, scaled: QtGui.QPixmap, origin: QtCore.QPoint) -> tuple[QtCore.QPointF, float]:
        """Where the sun or moon sits: along an arc across the sky, rising and setting at the
        sides and highest in the middle, so a glance tells you roughly what time of day it is."""
        width, height = scaled.width(), scaled.height()
        radius = max(8.0, width * 0.035)
        left = origin.x() + width * 0.14
        span = width * 0.72
        x = left + span * self.through
        import math
        top = origin.y() + height * 0.06
        bottom = origin.y() + height * 0.46
        y = bottom - (bottom - top) * math.sin(math.pi * self.through)
        return QtCore.QPointF(x, y), radius

    def showEvent(self, event):
        super().showEvent(event)
        if self.own_sky:
            self.flutter.start()
        if self.film is not None:
            self.film.start()

    def hideEvent(self, event):
        super().hideEvent(event)
        self.flutter.stop()
        if self.film is not None:
            self.film.stop()

    def draw_stars(self, painter: QtGui.QPainter, scaled: QtGui.QPixmap,
                   origin: QtCore.QPoint) -> None:
        """Twinkling stars, drawn in the ink of the day: white on the night screen, black on
        the white one, so they suit the line-drawn style either way."""
        moment = self.sky.now()
        ink = QtGui.QColor(palette().ink)
        size = max(1.6, scaled.width() * 0.0026)
        painter.setPen(Qt.PenStyle.NoPen)
        for across, down, twinkle, phase in self.sky.stars:
            ink.setAlpha(self.sky.star_alpha(twinkle, phase, moment))
            painter.setBrush(ink)
            middle = QtCore.QPointF(origin.x() + scaled.width() * across,
                                    origin.y() + scaled.height() * down)
            painter.drawEllipse(middle, size * twinkle, size * twinkle)
        painter.setBrush(Qt.BrushStyle.NoBrush)

    def draw_birds(self, painter: QtGui.QPainter, scaled: QtGui.QPixmap,
                   origin: QtCore.QPoint) -> None:
        """A few little birds, each a pair of wings that flap as it drifts across."""
        moment = self.sky.now()
        pen = QtGui.QPen(QtGui.QColor(palette().ink))
        span = max(4.0, scaled.width() * 0.012)
        pen.setWidthF(max(1.2, span * 0.16))
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        for bird in self.sky.birds:
            across, down, beat = self.sky.bird_at(bird, moment)
            if not -0.1 <= across <= 1.1:
                continue
            x = origin.x() + scaled.width() * across
            y = origin.y() + scaled.height() * down
            rise = span * 0.75 * beat                 # both wings go up and down together
            wing = QtGui.QPainterPath()                # a gull: two strokes meeting at the body
            wing.moveTo(x - span, y)
            wing.quadTo(x - span * 0.5, y - rise, x, y - rise * 0.12)
            wing.quadTo(x + span * 0.5, y - rise, x + span, y)
            painter.drawPath(wing)

    def draw_sky(self, painter: QtGui.QPainter, scaled: QtGui.QPixmap, origin: QtCore.QPoint) -> None:
        centre, radius = self.sky_body(scaled, origin)
        painter.setPen(Qt.PenStyle.NoPen)
        if self.sun_up:
            # The halo FADES out instead of being a flat disc at a quarter strength. Flat, it
            # is a quarter of amber mixed with whatever is behind -- a soft bloom on the white
            # screen and a hard dark brown ring on the black one, which is what the mat showed
            # whenever it was set to dark during the day. A gradient reads as light either
            # way: nearly the sun's own colour where it meets the sun, nothing at all by the
            # time it reaches the rim, so there is no edge to be the wrong colour.
            glow = QtGui.QRadialGradient(centre, radius * 1.9)
            near, far = QtGui.QColor(SUN), QtGui.QColor(SUN)
            near.setAlpha(150)
            far.setAlpha(0)
            glow.setColorAt(radius / (radius * 1.9), near)
            glow.setColorAt(0.0, near)
            glow.setColorAt(1.0, far)
            painter.setBrush(QtGui.QBrush(glow))
            painter.drawEllipse(centre, radius * 1.9, radius * 1.9)
            painter.setBrush(SUN)
            painter.drawEllipse(centre, radius, radius)
        else:
            # A crescent: the moon's disc with a second disc taken out of it.
            painter.setBrush(MOON)
            pen = QtGui.QPen(MOON_EDGE)
            pen.setWidthF(max(1.0, radius * 0.06))
            painter.setPen(pen)
            path = QtGui.QPainterPath()
            path.addEllipse(centre, radius, radius)
            bite = QtGui.QPainterPath()
            bite.addEllipse(QtCore.QPointF(centre.x() + radius * 0.42, centre.y() - radius * 0.18),
                            radius * 0.92, radius * 0.92)
            painter.drawPath(path.subtracted(bite))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(Qt.BrushStyle.NoBrush)

    def band_rect(self, box: QtCore.QRectF, which: str) -> QtCore.QRectF:
        """One of the two lines inside an arch, at the height the drawing had it."""
        top, bottom = self.bands[which]
        return QtCore.QRectF(box.x(), box.y() + box.height() * top,
                             box.width(), box.height() * (bottom - top))

    ROOM = 0.84      # of an arch's width the lettering may use, as the drawing's own does

    def fitted(self, line: QtCore.QRectF, text: str) -> QtGui.QFont:
        """As large as the band is tall, then shrunk until it fits across the arch."""
        font = QtGui.QFont(self.label_face) if self.label_face else QtGui.QFont()
        font.setWeight(QtGui.QFont.Weight(700))
        size = max(8, int(line.height()))
        font.setPixelSize(size)
        room = line.width() * self.ROOM
        while size > 8 and QtGui.QFontMetrics(font).horizontalAdvance(text) > room:
            size -= 1
            font.setPixelSize(size)
        return font

    def one_size(self, which: str, scale: float) -> QtGui.QFont:
        """One size for a whole row of arches: the largest that fits the worst of them.

        Fitted arch by arch, "Maghrib" comes out half the height of "Asr" beside it and the row
        reads as five unrelated labels. Harry's drawings have them all one size, which is what
        a row of the same thing should look like, so the longest word in the narrowest arch
        decides for all of them.
        """
        font = None
        for arch in self.arches:
            said = self.labels.get(arch.prayer)
            if not said:
                continue
            text = said[0] if which == "number" else said[1]
            if not text:
                continue
            box = QtCore.QRectF(0, 0, arch.box.width() * scale, arch.box.height() * scale)
            here = self.fitted(self.band_rect(box, which), text)
            if font is None or here.pixelSize() < font.pixelSize():
                font = here
        return font

    def draw_labels(self, painter: QtGui.QPainter, origin: QtCore.QPoint, scale: float) -> None:
        """The number of units and what kind they are, written into each arch.

        The arches on these drawings are solid, with their words taken out at build time, so
        this is ordinary lettering laid on top rather than anything lifted off the artwork --
        and that is the point: it comes from the pack, so it is Urdu on an Urdu mat, in the
        pack's own face, and changes with the language like everything else.

        On the main page it is the prayer's name, and the one whose time it is goes green. That
        used to be a stencil cut out of the artwork; now the word belongs to the app, it is the
        word in a different colour.
        """
        plain = QtGui.QColor("black") if self.flipped else QtGui.QColor("white")
        green = GREEN_DARK if self.flipped else GREEN
        fonts = {which: self.one_size(which, scale) for which in ("number", "label")}
        for arch in self.arches:
            said = self.labels.get(arch.prayer)
            if not said:
                continue
            painter.setPen(green if arch.prayer == self.lit else plain)
            box = QtCore.QRectF(origin.x() + arch.box.x() * scale,
                                origin.y() + arch.box.y() * scale,
                                arch.box.width() * scale, arch.box.height() * scale)
            for which, text in zip(("number", "label"), said):
                if not text or fonts[which] is None:
                    continue
                line = self.band_rect(box, which)
                painter.setFont(fonts[which])
                painter.drawText(line, int(Qt.AlignmentFlag.AlignCenter)
                                 | int(Qt.TextFlag.TextDontClip), text)

    def tint_the_lit_name(self, painter: QtGui.QPainter, drawn: QtGui.QPixmap,
                          origin: QtCore.QPoint, scale: float) -> None:
        """Turn the drawn name green in the arch whose time it is.

        Between 1.63 and 1.83 the app wrote the five names itself and the one that was due was
        simply written in green. The names are back in the artwork from 1.84, so the green has
        to be got out of a picture -- and the one thing that must not happen is a second word
        laid over Harry's.

        It is done by multiplying, which is one operation inside Qt rather than a loop over
        pixels here: inside an arch the panel is black and the lettering white, and multiplying
        by green leaves black alone (0 x anything is 0) and turns white into green. Turned
        inside out after dark the picture is the other way up -- black letters on a white panel
        -- and the same job is done by lightening, which keeps white white and lifts black to
        green. Either way nothing is drawn that was not already there; one colour is changed.

        Only the band the words sit in, measured off the ten drawings: the lettering runs from
        0.61 to 0.97 of the panel's height in the worst case (Hindi at the top, Urdu and Arabic
        at the bottom), and everything from 0.58 down to 0.98 is solid panel across the full
        width of the box. Outside that band the box's top corners take in the white wall beside
        the arch, which would come out green.
        """
        arch = next((a for a in self.arches if a.prayer == self.lit), None)
        if arch is None or drawn.isNull():
            return
        flip = self.flipped
        low, high = NAME_BAND
        here = QtCore.QRect(int(arch.box.x() * scale),
                            int((arch.box.y() + arch.box.height() * low) * scale),
                            int(arch.box.width() * scale),
                            int(arch.box.height() * (high - low) * scale))
        here = here.intersected(QtCore.QRect(QtCore.QPoint(0, 0), drawn.size()))
        if here.isEmpty():
            return
        piece = drawn.copy(here)
        tint = QtGui.QPainter(piece)
        tint.setCompositionMode(QtGui.QPainter.CompositionMode.CompositionMode_Lighten if flip
                                else QtGui.QPainter.CompositionMode.CompositionMode_Multiply)
        tint.fillRect(piece.rect(), GREEN_DARK if flip else GREEN)
        tint.end()
        painter.drawPixmap(origin + here.topLeft(), piece)

    def draw_minaret_glow(self, painter: QtGui.QPainter, origin: QtCore.QPoint, scale: float) -> None:
        """With no prayer due, the tops of the two minarets glow instead of an arch."""
        painter.setPen(Qt.PenStyle.NoPen)
        for box in self.minarets.values():
            where = QtCore.QRectF(origin.x() + box.x() * scale, origin.y() + box.y() * scale,
                                  box.width() * scale, box.height() * scale)
            middle = where.center()
            for step, alpha in ((2.0, 40), (1.5, 70), (1.15, 120)):
                painter.setBrush(QtGui.QColor(255, 193, 7, alpha))
                painter.drawEllipse(middle, where.width() * step * 0.5, where.height() * step * 0.5)
        painter.setBrush(Qt.BrushStyle.NoBrush)

    def paintEvent(self, _):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), QtGui.QColor(palette().paper))
        if not self.ready:
            return
        scaled, origin, scale = self.placement()
        flip = self.flipped
        if self.own_sky:
            if self.sun_up:
                self.draw_birds(painter, scaled, origin)
            else:
                self.draw_stars(painter, scaled, origin)
            self.draw_sky(painter, scaled, origin)
        if self.lit is None and self.idle_glow:
            self.draw_minaret_glow(painter, origin, scale)
        # The film REPLACES the still rather than going over it. Both are complete pictures of
        # the same drawing, so laying one on the other would leave the still's walkers standing
        # where frame one put them while the film's copies walked away from them. The still is
        # what gets drawn when there is no film, or before its first frame arrives.
        frame = self.film_frame(scaled.size(), flip)
        shown = scaled if frame is None else frame
        painter.drawPixmap(origin, shown)
        if self.labels:
            self.draw_labels(painter, origin, scale)
        if self.own_names and self.lit:
            self.tint_the_lit_name(painter, shown, origin, scale)

        # Which prayer it is now: its name on the arch in green, and its time in green in the
        # banner. No box over the arch; that was more shout than help. The green name is drawn
        # by draw_labels above, along with the other four -- it is the same word in a different
        # colour now that the app writes the words rather than the drawing carrying them.
        if self.time_text:
            box = QtCore.QRect(origin.x() + int(self.clock_box.x() * scale),
                               origin.y() + int(self.clock_box.y() * scale),
                               int(self.clock_box.width() * scale),
                               int(self.clock_box.height() * scale))
            font = self.clock_type(box, self.time_text, painter.font())
            dark = self.clock_dark != self.flipped
            self.draw_the_time(painter, font, self.clock_rect(box),
                               QtGui.QColor("black") if dark else CLOCK_INK)

    # Choosing

    def arch_centre(self, prayer: str) -> QtCore.QPoint | None:
        """The middle of one arch, in this widget's own pixels. The zoom uses it to know what
        it is walking towards."""
        if not self.ready:
            return None
        _, origin, scale = self.placement()
        for arch in self.arches:
            if arch.prayer == prayer:
                middle = arch.box.center()
                return QtCore.QPoint(origin.x() + int(middle.x() * scale),
                                     origin.y() + int(middle.y() * scale))
        return None

    def arch_at(self, point: QtCore.QPoint) -> str | None:
        if not self.ready:
            return None
        _, origin, scale = self.placement()
        x = (point.x() - origin.x()) / scale
        y = (point.y() - origin.y()) / scale
        for arch in self.arches:
            if arch.box.contains(int(x), int(y)):
                return arch.prayer
        return None

    def mousePressEvent(self, event):
        prayer = self.arch_at(event.position().toPoint())
        if not prayer and self.anywhere and self.arches:
            prayer = self.arches[0].prayer
        if prayer:
            self.chosen.emit(prayer)
