"""Starts the prayer app full screen. Run: python3 -m salaah [--windowed] [--cursor]"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .buttons import BluetoothButtons
from .power import HEADER, SleepSwitch
from .content import available_packs, load
from .qibla import NoCompass, find_compass
from .qt import API, QtCore, QtWidgets
from .settings import Settings
from .ui import QIBLA, MainWindow

ASSETS = Path(__file__).resolve().parent.parent / "assets"


def build_parser() -> argparse.ArgumentParser:
    """Every switch the app takes. Its own function so the switches can be checked without
    starting the app."""
    ap = argparse.ArgumentParser(prog="salaah")
    ap.add_argument("--windowed", action="store_true", help="run in a 1280x720 window instead of full screen")
    ap.add_argument("--cursor", action="store_true", help="show the mouse pointer for this run (Settings remembers it)")
    ap.add_argument("--no-buttons", action="store_true", help="don't read Bluetooth buttons directly")
    ap.add_argument("--no-sleep", action="store_true",
                    help="don't watch the sleep switch on GPIO 17")
    ap.add_argument("--aspect", default="fill",
                    help="shape of the drawing area, e.g. 16:9 or 4:3; 'fill' (the default) uses "
                         "the whole screen")
    ap.add_argument("--side-screen", choices=("auto", "off", "window"), default="auto",
                    help="the 7-inch posture screen: 'auto' uses a second screen if one is "
                         "plugged in, 'off' ignores it, 'window' shows it in a 600x1024 window "
                         "to try it on one monitor")
    ap.add_argument("--compass-stand-in", action="store_true",
                    help="try the Qibla screen without a compass chip: the arrow keys turn it")
    ap.add_argument("--tap-timings", action="store_true",
                    help="open the screen for tapping the word timings in with the ring, for "
                         "when the red runs ahead of or behind the voice. Not in Settings: it "
                         "is a job for building the mat, not for praying on it")
    ap.add_argument("--cover-screens", action="store_true",
                    help="don't ask the desktop to go full screen: cover each screen with a "
                         "borderless window instead. Use if a window lands on the wrong screen")
    ap.add_argument("--list-screens", action="store_true",
                    help="print the screens the Pi is reporting, and stop")
    ap.add_argument("--main-output", default="",
                    help="name of the screen the words go on, e.g. HDMI-A-1 (see --list-screens)")
    ap.add_argument("--side-output", default="",
                    help="name of the 7-inch posture screen, e.g. HDMI-A-2")
    ap.add_argument("--quit-after", type=float, default=0, help=argparse.SUPPRESS)  # smoke tests
    return ap


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    app = QtWidgets.QApplication(sys.argv[:1])
    app.setApplicationName("Salaah")
    content = load(ASSETS)
    packs = available_packs(ASSETS)
    settings = Settings.load()
    if args.cursor and not settings.cursor:
        settings.cursor = True
        settings.save()  # so it stays on next time, including when it starts by itself

    aspect = None
    if args.aspect.lower() not in ("fill", "none", ""):
        try:
            w, h = (float(x) for x in args.aspect.replace("/", ":").split(":"))
            aspect = w / h
        except (ValueError, ZeroDivisionError):
            print(f"--aspect {args.aspect!r} not understood; using the whole screen", file=sys.stderr)

    if args.list_screens:
        return list_screens(app)
    main_name, side_name = remembered(app, settings, args.main_output, args.side_output)
    main_screen, side_screen = pick_screens(app, main_name, side_name)
    remember(settings, main_screen, side_screen)
    use_side = args.side_screen == "window" or (args.side_screen == "auto" and side_screen is not None)
    screen = main_screen.geometry()
    height = 720 if args.windowed else screen.height()
    # If somebody has written a network onto the SD card, join it before anything else -- this
    # is the way in when the mat is somewhere new and the screen cannot be reached, and it is
    # the one path that must work when everything else has failed. It never stops the mat
    # starting: whatever happens it prints a line and carries on.
    try:
        from datetime import datetime
        from .network import Wifi, join_from_the_card
        said = join_from_the_card(Wifi(), when=datetime.now().strftime("%Y-%m-%d %H:%M"))
        if said:
            print(said, file=sys.stderr)
    except Exception as why:                       # never let the way in take the mat down
        print(f"wifi: the card could not be read ({why})", file=sys.stderr)

    # The compass is switched off for now (ui.QIBLA), so the chip is not looked for.
    compass = find_compass(stand_in=args.compass_stand_in) if QIBLA else NoCompass()
    print(f"compass: {compass.name}", file=sys.stderr)
    win = MainWindow(content, packs, settings, scale=max(0.5, height / 1080),
                     aspect=aspect, compass=compass, side=use_side)

    buttons = None
    if not args.no_buttons:
        buttons = BluetoothButtons(win.bridge.action.emit, win.bridge.devices.emit)
        buttons.start()
        if not buttons.available:
            print("python3-evdev not installed: Bluetooth buttons work only as normal key presses", file=sys.stderr)

    # The sleep switch. A press blanks the screens; another brings them back; holding it asks
    # whether to shut the mat down. This was the Pi 5's own power button until 1.98 and is a
    # plain switch on a pin now, because the mat runs on a Pi 4B, which has no power-button
    # circuit at all.
    #
    # BOTH GPIO 3 AND GPIO 17 are watched. The switch is moving to GPIO 3, because that is the
    # one pin whose state the bootloader reads, so the same button can start the mat from a
    # halt -- which is what makes offering a shutdown safe at all. Watching both means the wire
    # can move whenever suits rather than in step with an update. salaah/power.py says more.
    power = None
    if not args.no_sleep:
        power = SleepSwitch(win.bridge.power.emit, win.bridge.hold.emit)
        if power.start():
            print(f"sleep switch: watching {power.where}", file=sys.stderr)
            if power.why:                 # one pin took, the other did not; say which and why
                print(f"sleep switch: {power.why}", file=sys.stderr)
        else:
            print(f"sleep switch: {power.why}", file=sys.stderr)
            power = None

    # THE STATUS LIGHT, AFTER THE BUTTONS AND NOT BEFORE. Asking gpiozero for a Button
    # reconfigures its pin as an input, which is precisely how the LED went out when it lived on
    # GPIO 17 -- so it is lit once the pins above have been claimed and there is nothing left in
    # start-up to take it back.
    #
    # It says out loud whether it worked, like wlopm and the switch do, because `pinctrl set`
    # may need root depending on how a mat is set up: a light that never lights with nothing in
    # the log is a morning wasted on a wiring fault that is not a wiring fault. start() reports
    # which form it had to use by leaving it in led.prefix.
    if win.led.start():
        where = HEADER.get(win.led.pin, f"GPIO {win.led.pin}")
        how = " via sudo" if "sudo" in win.led.prefix else ""
        print(f"status light: lit on GPIO {win.led.pin} ({where}){how}", file=sys.stderr)
    else:
        print(f"status light: {win.led.why}", file=sys.stderr)

    # The fan, started the same way and reported the same way. Worth a line of its own at
    # start-up for the reason the light has one: when it does not work, the message names the
    # pin and what was tried, so the answer is on the screen rather than in a guess about
    # wiring. A mat with no pinctrl says so once here instead of silently never cooling.
    if win.fan.start():
        where = HEADER.get(win.fan.pin, f"GPIO {win.fan.pin}")
        how = " via sudo" if "sudo" in win.fan.prefix else ""
        print(f"fan: running on GPIO {win.fan.pin} ({where}){how}", file=sys.stderr)
    else:
        print(f"fan: {win.fan.why}", file=sys.stderr)

    win.apply_cursor()
    if args.windowed:
        win.resize(1280, 720)
        win.show()
    else:
        fill_screen(app, win, main_screen, args.cover_screens)
    if win.side is not None:
        if args.side_screen == "window" or side_screen is None:
            win.side.resize(600, 1024)
            win.side.show()
        else:
            fill_screen(app, win.side, side_screen, args.cover_screens)
        # Now that the panel has a window on a known screen, work out its own scale. Everything
        # on the 7in used to be measured in the MAIN screen's pixels, which only looked right
        # while the two screens were the same shape; on a 1080x1920 panel beside a 1920x1200
        # display every control came out about half size. See MainWindow.side_px.
        #
        # Before any game is built, which is what matters: games are built when a child first
        # opens one, and each sets up its own panel then, so they all get the measured scale.
        # The Knowledge Corner on the 7in is built with the main scale at construction and is
        # NOT re-laid out here -- same root cause, left alone deliberately rather than widened
        # into this change.
        # The named output, where there is one: its geometry is settled before the app draws
        # anything and cannot lose a race with the compositor, which is what the window's own
        # height did on the mat. A window asked for instead is one the app sized itself.
        win.measure_the_side_screen(None if args.side_screen == "window" else side_screen)
    # Some desktops (Wayland ones especially) put a window where they like and ignore the app.
    # Check a moment later that each window really is on its own screen, and say so if not.
    QtCore.QTimer.singleShot(1200, lambda: report_windows(win, main_screen, side_screen))
    win.begin()                     # the Qibla compass first, then the main screen
    # COUNT WHAT THE PI'S OWN SOFTWARE HAS OUTSTANDING, and only count it. Two minutes from
    # now and once a day after. Started HERE rather than in MainWindow.begin() on purpose: the
    # suite builds hundreds of MainWindows, and not one of them should shell out to apt. This
    # is the real app starting, which is the only place the question is worth asking.
    win.start_watching_the_packages()
    if args.tap_timings:
        win.open_timing()
    if args.quit_after:
        QtCore.QTimer.singleShot(int(args.quit_after * 1000), app.quit)
    for tr in content.translations.values():
        if tr.personal:
            print(f"personal translation loaded: {tr.name} ({tr.lang}.personal.json). "
                  "Private use only; delete it before packaging a release.", file=sys.stderr)
    # The version goes in the banner so that any log anybody sends -- a photograph of
    # the mat's terminal, a journalctl dump -- says which version produced it. Without
    # it, "none of the changes have happened" and "it crashed" look the same.
    from . import __version__
    print(f"Salaah {__version__} running with {API}", file=sys.stderr)

    # Say hello to the counting service, if and only if somebody said yes to that. HERE and
    # not in MainWindow, because MainWindow is built a thousand times by the test suite and
    # none of those should reach for a network; this runs once, in the real application, a
    # few seconds after the screen is up so it is never on the path of anything starting.
    #
    # The switch is checked AND the name has to exist -- onthemap.check_in does nothing
    # without one -- so the setting and the file would have to agree before anything is sent.
    if getattr(settings, "on_the_map", False):
        from . import onthemap
        here = (settings.latitude, settings.longitude)
        QtCore.QTimer.singleShot(
            5000, lambda: onthemap.in_the_background(lambda: onthemap.check_in(*here)))

    code = app.exec()
    if buttons:
        buttons.stop()
    if power:
        power.stop()
    win.shutdown()
    win.deleteLater()
    app.processEvents()
    return code


SEVEN_INCH = (1024, 600)        # the posture panel's own pixels, whichever way round it is stood
SLACK = 1.15                    # room for a panel that reports itself a little differently


def describe(screen) -> str:
    g = screen.geometry()
    return f"{screen.name()} {g.width()}x{g.height()} at {g.x()},{g.y()}"


def area(screen) -> int:
    g = screen.geometry()
    return g.width() * g.height()


def looks_like_the_seven_inch(screen) -> bool:
    """Is this the 7" posture panel? Judged by its shape rather than its name or its socket, so
    it comes out right whichever cable went into which port, and whether the desktop has it
    upright (600x1024) or flat (1024x600)."""
    g = screen.geometry()
    long_edge, short_edge = max(g.width(), g.height()), min(g.width(), g.height())
    return long_edge <= SEVEN_INCH[0] * SLACK and short_edge <= SEVEN_INCH[1] * SLACK


def list_screens(app) -> int:
    """What the Pi is reporting. Run this first when a window lands on the wrong screen."""
    import os
    print(f"session: {os.environ.get('XDG_SESSION_TYPE', 'unknown')}, "
          f"Qt platform: {app.platformName()}")
    main_screen, side_screen = pick_screens(app)
    for screen in app.screens():
        if screen is main_screen:
            role = "  <- the words"
        elif screen is side_screen:
            role = "  <- the posture (7\")"
        else:
            role = "  <- not used"
        print(f"  {describe(screen)}{role}")
    print("The 7-inch panel is recognised by its shape, so the sockets can be either way round.")
    print("Pass a name to --main-output or --side-output to overrule it, e.g. --main-output HDMI-A-1")
    return 0


def by_name(app, name: str):
    """A screen by name, matched loosely: HDMI-A-1, hdmi-a-1 or just 1 all find the same one."""
    if not name:
        return None
    wanted = name.strip().lower()
    for screen in app.screens():
        if screen.name().lower() in (wanted, f"hdmi-a-{wanted}"):
            return screen
    print(f"no screen named {name!r}; run --list-screens to see the names", file=sys.stderr)
    return None


def pick_screens(app, main_name: str = "", side_name: str = ""):
    """The main screen and the 7" one.

    A name given for either wins. Otherwise the 7" is found by its shape, and the largest screen
    that is left over holds the words. Nothing depends on which HDMI socket a screen is in, or on
    the order the Pi happens to report them in, so the same two screens come out the same way
    round on every boot.
    """
    screens = sorted(app.screens(), key=area, reverse=True)
    if not screens:
        return app.primaryScreen(), None
    main = by_name(app, main_name)
    side = by_name(app, side_name)
    why = "named"
    if side is None:
        others = [s for s in screens if s is not main]
        if main is None:
            others = others[1:]                      # the largest is the words screen
        matches = [s for s in others if looks_like_the_seven_inch(s)]
        if matches:
            side, why = matches[-1], "by its shape"
        elif others:
            side, why = others[-1], "the smallest screen left over"
    if main is None:
        main = next((s for s in screens if s is not side), screens[0])
    if side is main:
        side = None
    print(f"main screen: {describe(main)}", file=sys.stderr)
    print(f"posture screen: {describe(side) + ' (' + why + ')' if side else 'none'}",
          file=sys.stderr)
    return main, side


def remembered(app, settings, main_name: str, side_name: str) -> tuple[str, str]:
    """Which screen names to use: one given on the command line this run, else the one last
    given, which is remembered in Settings.

    A remembered name is only used while it still makes sense. Screen names can come back in a
    different order after a reboot, and a stale name would then point at the wrong panel, so a
    remembered main screen that now looks like the 7" is dropped, as is a remembered 7" that is
    now the largest screen. Detection by shape takes over, and the new choice is remembered.
    """
    screens = sorted(app.screens(), key=area, reverse=True)
    main, side = main_name, side_name
    if not main and settings.main_output:
        kept = by_name(app, settings.main_output)
        if kept is not None and not looks_like_the_seven_inch(kept):
            main = settings.main_output
        else:
            print(f"forgetting the remembered main screen {settings.main_output!r}: it is not "
                  "there any more, or it is the small panel now", file=sys.stderr)
    if not side and settings.side_output:
        kept = by_name(app, settings.side_output)
        taken = by_name(app, main) if main else None
        if kept is not None and kept is not taken and (len(screens) < 2 or kept is not screens[0]):
            side = settings.side_output
        else:
            print(f"forgetting the remembered posture screen {settings.side_output!r}: it is not "
                  "there any more, or it is the words screen now", file=sys.stderr)
    return main, side


def remember(settings, main_screen, side_screen) -> None:
    """Writes the screens that were actually used into Settings, so the next run starts from the
    same place even if the Pi reports them in a different order."""
    main = main_screen.name() if main_screen is not None else ""
    side = side_screen.name() if side_screen is not None else ""
    if (main, side) != (settings.main_output, settings.side_output):
        settings.main_output, settings.side_output = main, side
        settings.save()


def report_windows(win, main_screen, side_screen) -> None:
    """Says which screen each window actually ended up on.

    EVERY TOUCH OF A SCREEN IN HERE CAN RAISE, for the reason set out in fill_screen: a
    display that has gone leaves a QScreen wrapper that looks fine until it is used. This
    function only reports and tidies, so there is nothing in it worth taking a mat down for.
    """
    try:
        _report_windows(win, main_screen, side_screen)
    except RuntimeError as gone:
        print(f"report_windows: a screen went away while the windows were being checked "
              f"({gone})", file=sys.stderr)


def _report_windows(win, main_screen, side_screen) -> None:
    def where(widget):
        handle = widget.windowHandle()
        screen = handle.screen() if handle is not None else None
        return screen.name() if screen is not None else "?"

    wanted_main = main_screen.name() if main_screen else "?"
    print(f"words window on: {where(win)} (wanted {wanted_main}), "
          f"{win.width()}x{win.height()}", file=sys.stderr)
    if win.side is not None:
        wanted_side = side_screen.name() if side_screen else "a window"
        print(f"posture window on: {where(win.side)} (wanted {wanted_side}), "
              f"{win.side.width()}x{win.side.height()}", file=sys.stderr)
    if win.side is not None and side_screen is not None and where(win) == where(win.side):
        print("Both windows landed on the same screen. The desktop is ignoring where the app "
              "asks its windows to go; see 'Two screens' in the README.", file=sys.stderr)
    # A last resort, a moment after the desktop has settled: cover each screen by hand.
    for widget, screen in ((win, main_screen), (win.side, side_screen)):
        if widget is None or screen is None:
            continue
        handle = widget.windowHandle()
        if handle is not None and handle.screen() is not screen:
            cover(widget, screen)


def still_connected(app, screen) -> bool:
    """Is this QScreen still a screen, or has Qt thrown it away underneath us?

    A QScreen is a handle on a C++ object the toolkit owns. Unplug a display, or let the
    compositor re-enumerate its outputs, and Qt deletes that object -- while Python goes on
    holding a wrapper that looks perfectly fine until it is touched, and then raises.
    """
    try:
        return screen is not None and screen in app.screens()
    except RuntimeError:
        return False


def fill_screen(app, widget, screen, by_hand: bool = False) -> None:
    """Fills one particular screen with a window.

    Asking to go full screen leaves the choice of screen to the desktop, and some desktops
    choose the wrong one. So the window is first shown, small, at the corner of the screen it
    belongs to; the desktop then has only one screen to choose from when it is told to go full
    screen. If it still gets it wrong, [cover] takes the screen over without asking.

    A SCREEN CAN DIE BETWEEN BEING CHOSEN AND BEING USED, and until 2.39 that took the mat
    down on the way up. From Harry's startup-error.log:

        2026-11-14 19:45:09  version 2.25
          File ".../salaah/main.py", line 402, in cover
            box = screen.geometry()
        RuntimeError: wrapped C++ object of type QScreen has been deleted

    The screen is picked near the top of main() and used here, a long way down -- the status
    light, the fan and the cursor all happen in between. On a mat whose main display sometimes
    does not come back, that gap is long enough for the display to go, and Qt to delete the
    QScreen, while this function is still holding it.

    What happened next is the whole reason it mattered: run.sh restarted the app two seconds
    later, the restarted app found the prayer still inside its two-minute grace window and
    called the azaan AGAIN, and the player belonging to the app that died was still sounding
    with nothing able to stop it. That is the azaan playing twice, and the stop button only
    reaching one of them.

    So nothing here may raise on account of a screen. A mat that cannot work out which display
    to use still has to start: it shows its window wherever the desktop will put it and says so
    on stderr, which is a mat with its windows on the wrong screen rather than no mat at all.
    """
    # THE CATCH BELOW IS WHAT HOLDS; this check is not load-bearing and it is worth saying so.
    # Removing it as a sabotage did NOT make any test fail, and that is the correct answer
    # rather than a hole: with only the catch, a screen that has already gone still ends with
    # the window shown. What the check buys is a clearer line on stderr -- "it was gone before
    # we started" reads differently from "it went while we were placing it" -- and not
    # half-placing a window before the exception arrives. Both are worth having and neither is
    # worth pretending a test guards.
    if not still_connected(app, screen):
        if screen is not None:
            print("fill_screen: the screen this window was meant for is no longer there; "
                  "showing it wherever the desktop puts it", file=sys.stderr)
        widget.show()
        return
    try:
        _fill_screen(app, widget, screen, by_hand)
    except RuntimeError as gone:
        # The check above is not enough on its own and is not meant to be: the display can go
        # between being asked about and being used, which is a race no amount of asking first
        # can close. This is the part that actually holds.
        print(f"fill_screen: the screen went away while the window was being placed ({gone}); "
              f"showing it wherever the desktop puts it", file=sys.stderr)
        try:
            widget.show()
        except RuntimeError:
            pass


def _fill_screen(app, widget, screen, by_hand: bool = False) -> None:
    if screen is None:
        widget.show()
        return
    if by_hand:
        widget.show()
        cover(widget, screen)
        app.processEvents()
        return
    box = screen.geometry()
    widget.winId()                          # makes the native window, so it can be placed
    handle = widget.windowHandle()
    if handle is not None:
        handle.setScreen(screen)
    widget.setGeometry(box.x(), box.y(), min(640, box.width()), min(480, box.height()))
    widget.show()
    app.processEvents()
    # QWidget.move by name, since the main window has a move() of its own (the prayer steps).
    QtWidgets.QWidget.move(widget, box.x(), box.y())   # the desktop may have moved it on mapping
    app.processEvents()
    widget.showFullScreen()
    app.processEvents()
    if widget.windowHandle() is not None and widget.windowHandle().screen() is not screen:
        cover(widget, screen)
        app.processEvents()


def cover(widget, screen) -> None:
    """Takes a screen over the blunt way: a borderless window the size of the screen, put where
    the screen is. No full-screen request, so the desktop has no say in which screen it is."""
    from .qt import Qt
    box = screen.geometry()
    widget.setWindowState(Qt.WindowState.WindowNoState)
    widget.setWindowFlag(Qt.WindowType.FramelessWindowHint, True)
    widget.showNormal()
    widget.setGeometry(box)
    QtWidgets.QWidget.move(widget, box.x(), box.y())
    widget.raise_()
    print(f"{widget.windowTitle()!r}: the desktop would not put it on {screen.name()}, "
          f"so it was covered by hand", file=sys.stderr)


if __name__ == "__main__":
    sys.exit(main())
